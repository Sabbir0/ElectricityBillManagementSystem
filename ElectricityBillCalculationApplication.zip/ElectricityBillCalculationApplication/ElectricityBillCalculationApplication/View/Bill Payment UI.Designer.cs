﻿namespace ElectricityBillCalculationApplication.View
{
    partial class BillPaymentUI
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonDone = new System.Windows.Forms.Button();
            this.buttonRefresh = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.buttonPaymentRefresh = new System.Windows.Forms.Button();
            this.buttonPaymentDone = new System.Windows.Forms.Button();
            this.textBoxDue = new System.Windows.Forms.TextBox();
            this.textBoxPay = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.groupBoxPreviewBill = new System.Windows.Forms.GroupBox();
            this.labelDate = new System.Windows.Forms.Label();
            this.labelMeterNo = new System.Windows.Forms.Label();
            this.labelMonth = new System.Windows.Forms.Label();
            this.labelName = new System.Windows.Forms.Label();
            this.labelFlat = new System.Windows.Forms.Label();
            this.labelVat = new System.Windows.Forms.Label();
            this.labelDemandCharge = new System.Windows.Forms.Label();
            this.labelServiceCharge = new System.Windows.Forms.Label();
            this.labelUnitBill = new System.Windows.Forms.Label();
            this.labelTotalUnit = new System.Windows.Forms.Label();
            this.labelPreviousUnit = new System.Windows.Forms.Label();
            this.labelPresentUnit = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.labelDue = new System.Windows.Forms.Label();
            this.labelPay = new System.Windows.Forms.Label();
            this.buttonPrintBill = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.labelTotalPayble = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.comboBoxDate = new System.Windows.Forms.ComboBox();
            this.comboBoxFlat = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.textBoxName = new System.Windows.Forms.TextBox();
            this.textBoxYear = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBoxPreviewBill.SuspendLayout();
            this.SuspendLayout();
            // 
            // buttonDone
            // 
            this.buttonDone.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.buttonDone.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonDone.Location = new System.Drawing.Point(355, 81);
            this.buttonDone.Name = "buttonDone";
            this.buttonDone.Size = new System.Drawing.Size(75, 23);
            this.buttonDone.TabIndex = 24;
            this.buttonDone.Text = "Done";
            this.buttonDone.UseVisualStyleBackColor = false;
            this.buttonDone.Click += new System.EventHandler(this.buttonDone_Click);
            // 
            // buttonRefresh
            // 
            this.buttonRefresh.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.buttonRefresh.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonRefresh.Location = new System.Drawing.Point(355, 48);
            this.buttonRefresh.Name = "buttonRefresh";
            this.buttonRefresh.Size = new System.Drawing.Size(75, 23);
            this.buttonRefresh.TabIndex = 23;
            this.buttonRefresh.Text = "Refresh";
            this.buttonRefresh.UseVisualStyleBackColor = false;
            this.buttonRefresh.Click += new System.EventHandler(this.buttonRefresh_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.buttonPaymentRefresh);
            this.groupBox1.Controls.Add(this.buttonPaymentDone);
            this.groupBox1.Controls.Add(this.textBoxDue);
            this.groupBox1.Controls.Add(this.textBoxPay);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(466, 15);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(381, 98);
            this.groupBox1.TabIndex = 22;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Payment";
            // 
            // buttonPaymentRefresh
            // 
            this.buttonPaymentRefresh.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.buttonPaymentRefresh.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonPaymentRefresh.Location = new System.Drawing.Point(235, 34);
            this.buttonPaymentRefresh.Name = "buttonPaymentRefresh";
            this.buttonPaymentRefresh.Size = new System.Drawing.Size(112, 24);
            this.buttonPaymentRefresh.TabIndex = 4;
            this.buttonPaymentRefresh.Text = "Refresh";
            this.buttonPaymentRefresh.UseVisualStyleBackColor = false;
            this.buttonPaymentRefresh.Click += new System.EventHandler(this.buttonPaymentRefresh_Click);
            // 
            // buttonPaymentDone
            // 
            this.buttonPaymentDone.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.buttonPaymentDone.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonPaymentDone.Location = new System.Drawing.Point(235, 62);
            this.buttonPaymentDone.Name = "buttonPaymentDone";
            this.buttonPaymentDone.Size = new System.Drawing.Size(112, 24);
            this.buttonPaymentDone.TabIndex = 4;
            this.buttonPaymentDone.Text = "Done";
            this.buttonPaymentDone.UseVisualStyleBackColor = false;
            this.buttonPaymentDone.Click += new System.EventHandler(this.buttonPaymentDone_Click);
            // 
            // textBoxDue
            // 
            this.textBoxDue.Location = new System.Drawing.Point(82, 61);
            this.textBoxDue.Name = "textBoxDue";
            this.textBoxDue.Size = new System.Drawing.Size(134, 24);
            this.textBoxDue.TabIndex = 3;
            // 
            // textBoxPay
            // 
            this.textBoxPay.Location = new System.Drawing.Point(82, 33);
            this.textBoxPay.Name = "textBoxPay";
            this.textBoxPay.Size = new System.Drawing.Size(134, 24);
            this.textBoxPay.TabIndex = 2;
            this.textBoxPay.MouseLeave += new System.EventHandler(this.textBoxPay_MouseLeave);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(26, 62);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(53, 18);
            this.label6.TabIndex = 1;
            this.label6.Text = "Due : ";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(25, 34);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(51, 18);
            this.label5.TabIndex = 0;
            this.label5.Text = "Pay : ";
            // 
            // groupBoxPreviewBill
            // 
            this.groupBoxPreviewBill.Controls.Add(this.labelDate);
            this.groupBoxPreviewBill.Controls.Add(this.labelMeterNo);
            this.groupBoxPreviewBill.Controls.Add(this.labelMonth);
            this.groupBoxPreviewBill.Controls.Add(this.labelName);
            this.groupBoxPreviewBill.Controls.Add(this.labelFlat);
            this.groupBoxPreviewBill.Controls.Add(this.labelVat);
            this.groupBoxPreviewBill.Controls.Add(this.labelDemandCharge);
            this.groupBoxPreviewBill.Controls.Add(this.labelServiceCharge);
            this.groupBoxPreviewBill.Controls.Add(this.labelUnitBill);
            this.groupBoxPreviewBill.Controls.Add(this.labelTotalUnit);
            this.groupBoxPreviewBill.Controls.Add(this.labelPreviousUnit);
            this.groupBoxPreviewBill.Controls.Add(this.labelPresentUnit);
            this.groupBoxPreviewBill.Controls.Add(this.label16);
            this.groupBoxPreviewBill.Controls.Add(this.label15);
            this.groupBoxPreviewBill.Controls.Add(this.label14);
            this.groupBoxPreviewBill.Controls.Add(this.label13);
            this.groupBoxPreviewBill.Controls.Add(this.label12);
            this.groupBoxPreviewBill.Controls.Add(this.label11);
            this.groupBoxPreviewBill.Controls.Add(this.label10);
            this.groupBoxPreviewBill.Controls.Add(this.label9);
            this.groupBoxPreviewBill.Controls.Add(this.label8);
            this.groupBoxPreviewBill.Controls.Add(this.label4);
            this.groupBoxPreviewBill.Controls.Add(this.label19);
            this.groupBoxPreviewBill.Controls.Add(this.label20);
            this.groupBoxPreviewBill.Controls.Add(this.labelDue);
            this.groupBoxPreviewBill.Controls.Add(this.labelPay);
            this.groupBoxPreviewBill.Controls.Add(this.buttonPrintBill);
            this.groupBoxPreviewBill.Controls.Add(this.button2);
            this.groupBoxPreviewBill.Controls.Add(this.labelTotalPayble);
            this.groupBoxPreviewBill.Controls.Add(this.label17);
            this.groupBoxPreviewBill.Controls.Add(this.label18);
            this.groupBoxPreviewBill.Controls.Add(this.label7);
            this.groupBoxPreviewBill.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBoxPreviewBill.Location = new System.Drawing.Point(18, 119);
            this.groupBoxPreviewBill.Name = "groupBoxPreviewBill";
            this.groupBoxPreviewBill.Size = new System.Drawing.Size(829, 284);
            this.groupBoxPreviewBill.TabIndex = 25;
            this.groupBoxPreviewBill.TabStop = false;
            this.groupBoxPreviewBill.Text = "Total  Payble Bill";
            // 
            // labelDate
            // 
            this.labelDate.AutoSize = true;
            this.labelDate.Location = new System.Drawing.Point(175, 28);
            this.labelDate.Name = "labelDate";
            this.labelDate.Size = new System.Drawing.Size(0, 18);
            this.labelDate.TabIndex = 49;
            // 
            // labelMeterNo
            // 
            this.labelMeterNo.AutoSize = true;
            this.labelMeterNo.Location = new System.Drawing.Point(175, 75);
            this.labelMeterNo.Name = "labelMeterNo";
            this.labelMeterNo.Size = new System.Drawing.Size(0, 18);
            this.labelMeterNo.TabIndex = 48;
            // 
            // labelMonth
            // 
            this.labelMonth.AutoSize = true;
            this.labelMonth.Location = new System.Drawing.Point(174, 54);
            this.labelMonth.Name = "labelMonth";
            this.labelMonth.Size = new System.Drawing.Size(0, 18);
            this.labelMonth.TabIndex = 47;
            // 
            // labelName
            // 
            this.labelName.AutoSize = true;
            this.labelName.Location = new System.Drawing.Point(174, 97);
            this.labelName.Name = "labelName";
            this.labelName.Size = new System.Drawing.Size(0, 18);
            this.labelName.TabIndex = 46;
            // 
            // labelFlat
            // 
            this.labelFlat.AutoSize = true;
            this.labelFlat.Location = new System.Drawing.Point(176, 121);
            this.labelFlat.Name = "labelFlat";
            this.labelFlat.Size = new System.Drawing.Size(0, 18);
            this.labelFlat.TabIndex = 45;
            // 
            // labelVat
            // 
            this.labelVat.AutoSize = true;
            this.labelVat.Location = new System.Drawing.Point(628, 167);
            this.labelVat.Name = "labelVat";
            this.labelVat.Size = new System.Drawing.Size(0, 18);
            this.labelVat.TabIndex = 44;
            // 
            // labelDemandCharge
            // 
            this.labelDemandCharge.AutoSize = true;
            this.labelDemandCharge.Location = new System.Drawing.Point(627, 144);
            this.labelDemandCharge.Name = "labelDemandCharge";
            this.labelDemandCharge.Size = new System.Drawing.Size(0, 18);
            this.labelDemandCharge.TabIndex = 43;
            // 
            // labelServiceCharge
            // 
            this.labelServiceCharge.AutoSize = true;
            this.labelServiceCharge.Location = new System.Drawing.Point(626, 119);
            this.labelServiceCharge.Name = "labelServiceCharge";
            this.labelServiceCharge.Size = new System.Drawing.Size(0, 18);
            this.labelServiceCharge.TabIndex = 42;
            // 
            // labelUnitBill
            // 
            this.labelUnitBill.AutoSize = true;
            this.labelUnitBill.Location = new System.Drawing.Point(626, 98);
            this.labelUnitBill.Name = "labelUnitBill";
            this.labelUnitBill.Size = new System.Drawing.Size(0, 18);
            this.labelUnitBill.TabIndex = 41;
            // 
            // labelTotalUnit
            // 
            this.labelTotalUnit.AutoSize = true;
            this.labelTotalUnit.Location = new System.Drawing.Point(626, 74);
            this.labelTotalUnit.Name = "labelTotalUnit";
            this.labelTotalUnit.Size = new System.Drawing.Size(0, 18);
            this.labelTotalUnit.TabIndex = 40;
            // 
            // labelPreviousUnit
            // 
            this.labelPreviousUnit.AutoSize = true;
            this.labelPreviousUnit.Location = new System.Drawing.Point(176, 168);
            this.labelPreviousUnit.Name = "labelPreviousUnit";
            this.labelPreviousUnit.Size = new System.Drawing.Size(0, 18);
            this.labelPreviousUnit.TabIndex = 39;
            // 
            // labelPresentUnit
            // 
            this.labelPresentUnit.AutoSize = true;
            this.labelPresentUnit.Location = new System.Drawing.Point(176, 143);
            this.labelPresentUnit.Name = "labelPresentUnit";
            this.labelPresentUnit.Size = new System.Drawing.Size(0, 18);
            this.labelPresentUnit.TabIndex = 38;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(500, 170);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(53, 18);
            this.label16.TabIndex = 37;
            this.label16.Text = "VAT : ";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(501, 98);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(81, 18);
            this.label15.TabIndex = 36;
            this.label15.Text = "Unit Bill : ";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(501, 143);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(144, 18);
            this.label14.TabIndex = 35;
            this.label14.Text = "Demand Charge : ";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(500, 119);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(138, 18);
            this.label13.TabIndex = 34;
            this.label13.Text = "Service Charge : ";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(501, 72);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(96, 18);
            this.label12.TabIndex = 33;
            this.label12.Text = "Total Unit : ";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(50, 168);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(119, 18);
            this.label11.TabIndex = 32;
            this.label11.Text = "Previous Unit: ";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(50, 143);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(116, 18);
            this.label10.TabIndex = 31;
            this.label10.Text = "Present Unit : ";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(50, 120);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(51, 18);
            this.label9.TabIndex = 30;
            this.label9.Text = "Flat : ";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(50, 97);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(67, 18);
            this.label8.TabIndex = 29;
            this.label8.Text = "Name : ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(51, 28);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(58, 18);
            this.label4.TabIndex = 27;
            this.label4.Text = "Date : ";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(51, 75);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(93, 18);
            this.label19.TabIndex = 28;
            this.label19.Text = "Meter No : ";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(50, 54);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(70, 18);
            this.label20.TabIndex = 26;
            this.label20.Text = "Month : ";
            // 
            // labelDue
            // 
            this.labelDue.AutoSize = true;
            this.labelDue.Location = new System.Drawing.Point(176, 248);
            this.labelDue.Name = "labelDue";
            this.labelDue.Size = new System.Drawing.Size(0, 18);
            this.labelDue.TabIndex = 25;
            // 
            // labelPay
            // 
            this.labelPay.AutoSize = true;
            this.labelPay.Location = new System.Drawing.Point(174, 225);
            this.labelPay.Name = "labelPay";
            this.labelPay.Size = new System.Drawing.Size(0, 18);
            this.labelPay.TabIndex = 24;
            // 
            // buttonPrintBill
            // 
            this.buttonPrintBill.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.buttonPrintBill.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonPrintBill.Location = new System.Drawing.Point(683, 218);
            this.buttonPrintBill.Name = "buttonPrintBill";
            this.buttonPrintBill.Size = new System.Drawing.Size(112, 36);
            this.buttonPrintBill.TabIndex = 23;
            this.buttonPrintBill.Text = "Print";
            this.buttonPrintBill.UseVisualStyleBackColor = false;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(569, 218);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(108, 36);
            this.button2.TabIndex = 22;
            this.button2.Text = "Close";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // labelTotalPayble
            // 
            this.labelTotalPayble.AutoSize = true;
            this.labelTotalPayble.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTotalPayble.Location = new System.Drawing.Point(158, 194);
            this.labelTotalPayble.Name = "labelTotalPayble";
            this.labelTotalPayble.Size = new System.Drawing.Size(0, 24);
            this.labelTotalPayble.TabIndex = 18;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(9, 194);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(165, 25);
            this.label17.TabIndex = 10;
            this.label17.Text = "Total Payble : ";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(117, 248);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(53, 18);
            this.label18.TabIndex = 4;
            this.label18.Text = "Due : ";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(117, 225);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(51, 18);
            this.label7.TabIndex = 4;
            this.label7.Text = "Pay : ";
            // 
            // comboBoxDate
            // 
            this.comboBoxDate.FormattingEnabled = true;
            this.comboBoxDate.Items.AddRange(new object[] {
            "January",
            "February",
            "March",
            "April",
            "May",
            "June",
            "July",
            "August",
            "September",
            "October",
            "November",
            "December"});
            this.comboBoxDate.Location = new System.Drawing.Point(105, 19);
            this.comboBoxDate.Name = "comboBoxDate";
            this.comboBoxDate.Size = new System.Drawing.Size(101, 21);
            this.comboBoxDate.TabIndex = 0;
            // 
            // comboBoxFlat
            // 
            this.comboBoxFlat.FormattingEnabled = true;
            this.comboBoxFlat.Location = new System.Drawing.Point(105, 49);
            this.comboBoxFlat.Name = "comboBoxFlat";
            this.comboBoxFlat.Size = new System.Drawing.Size(244, 21);
            this.comboBoxFlat.TabIndex = 1;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(29, 22);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(70, 18);
            this.label3.TabIndex = 17;
            this.label3.Text = "Month : ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(29, 48);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(51, 18);
            this.label2.TabIndex = 16;
            this.label2.Text = "Flat : ";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(29, 78);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(67, 18);
            this.label1.TabIndex = 15;
            this.label1.Text = "Name : ";
            // 
            // textBoxName
            // 
            this.textBoxName.Location = new System.Drawing.Point(105, 79);
            this.textBoxName.Name = "textBoxName";
            this.textBoxName.Size = new System.Drawing.Size(244, 20);
            this.textBoxName.TabIndex = 26;
            this.textBoxName.Click += new System.EventHandler(this.textBoxName_Click);
            // 
            // textBoxYear
            // 
            this.textBoxYear.Location = new System.Drawing.Point(267, 22);
            this.textBoxYear.Name = "textBoxYear";
            this.textBoxYear.Size = new System.Drawing.Size(82, 20);
            this.textBoxYear.TabIndex = 27;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(212, 21);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(52, 18);
            this.label21.TabIndex = 28;
            this.label21.Text = "Year :";
            // 
            // BillPaymentUI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(866, 415);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.textBoxYear);
            this.Controls.Add(this.textBoxName);
            this.Controls.Add(this.buttonDone);
            this.Controls.Add(this.buttonRefresh);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.groupBoxPreviewBill);
            this.Controls.Add(this.comboBoxDate);
            this.Controls.Add(this.comboBoxFlat);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "BillPaymentUI";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "BillPaymentUI";
            this.Load += new System.EventHandler(this.BillPaymentUI_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBoxPreviewBill.ResumeLayout(false);
            this.groupBoxPreviewBill.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonDone;
        private System.Windows.Forms.Button buttonRefresh;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button buttonPaymentDone;
        private System.Windows.Forms.TextBox textBoxDue;
        private System.Windows.Forms.TextBox textBoxPay;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.GroupBox groupBoxPreviewBill;
        private System.Windows.Forms.Button buttonPrintBill;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label labelTotalPayble;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox comboBoxDate;
        private System.Windows.Forms.ComboBox comboBoxFlat;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label labelDue;
        private System.Windows.Forms.Label labelPay;
        private System.Windows.Forms.Button buttonPaymentRefresh;
        private System.Windows.Forms.Label labelDate;
        private System.Windows.Forms.Label labelMeterNo;
        private System.Windows.Forms.Label labelMonth;
        private System.Windows.Forms.Label labelName;
        private System.Windows.Forms.Label labelFlat;
        private System.Windows.Forms.Label labelVat;
        private System.Windows.Forms.Label labelDemandCharge;
        private System.Windows.Forms.Label labelServiceCharge;
        private System.Windows.Forms.Label labelUnitBill;
        private System.Windows.Forms.Label labelTotalUnit;
        private System.Windows.Forms.Label labelPreviousUnit;
        private System.Windows.Forms.Label labelPresentUnit;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox textBoxName;
        private System.Windows.Forms.TextBox textBoxYear;
        private System.Windows.Forms.Label label21;
    }
}