﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ElectricityBillCalculationApplication.Model;

namespace ElectricityBillCalculationApplication.View
{
    public partial class UpdateVatAndChargeUI : Form
    {
        public UpdateVatAndChargeUI()
        {
            InitializeComponent();
            LoadVatAndCharge();
        }

        private void LoadVatAndCharge()
        {
            List<VatAndCharge> vatAndChargeList = new List<VatAndCharge>();
            VatAndCharge aVatAndCharge = new VatAndCharge();
            vatAndChargeList = aVatAndCharge.VatCharge();
            dataGridViewUpdateVatAndCharge.DataSource = vatAndChargeList;

        }
       public void ClearField()
        {
            textBoxServiceCharge.Text = "";
            textBoxDemandCharge.Text = "";
            textBoxVat.Text = "";
        }

        private void buttonUpdate_Click(object sender, EventArgs e)
        {
            List<VatAndCharge> vatAndChargeList = new List<VatAndCharge>();
            VatAndCharge aVatAndCharge = new VatAndCharge();
            vatAndChargeList = aVatAndCharge.VatCharge();
            foreach (var v in vatAndChargeList)
            {
            
              if (!string.IsNullOrEmpty(textBoxServiceCharge.Text))
                {
                    aVatAndCharge.UpdateVatCharge(v.VatAndChargeId, Convert.ToDouble(textBoxServiceCharge.Text), v.DemandCharge, v.VatPercentage );
                    MessageBox.Show("Service Charge Update Successfully !");
                }
               else
                {
                    MessageBox.Show("Field Empty!");
                }
                ClearField();
                LoadVatAndCharge();
            }
        }

        private void buttonUpdateDemand_Click(object sender, EventArgs e)
        {
            List<VatAndCharge> vatAndChargeList = new List<VatAndCharge>();
            VatAndCharge aVatAndCharge = new VatAndCharge();
            vatAndChargeList = aVatAndCharge.VatCharge();
            foreach (var v in vatAndChargeList)
            {
             if (!string.IsNullOrEmpty(textBoxDemandCharge.Text) )
                {
                    aVatAndCharge.UpdateVatCharge(v.VatAndChargeId, v.ServiceCharge, Convert.ToDouble(textBoxDemandCharge.Text), v.VatPercentage);
                    MessageBox.Show(" Demand Charge Update Successfully !");
                }
                else
                {
                    MessageBox.Show("Field Empty!");
                }
                ClearField();
                LoadVatAndCharge();
            }
        }

        private void buttonVatPercentage_Click(object sender, EventArgs e)
        {
            List<VatAndCharge> vatAndChargeList = new List<VatAndCharge>();
            VatAndCharge aVatAndCharge = new VatAndCharge();
            vatAndChargeList = aVatAndCharge.VatCharge();
            foreach (var v in vatAndChargeList)
            {
              if (!string.IsNullOrEmpty(textBoxVat.Text))
                {
                    aVatAndCharge.UpdateVatCharge(v.VatAndChargeId, v.ServiceCharge, v.DemandCharge, Convert.ToDouble(textBoxVat.Text));
                    MessageBox.Show("  Vat Percentage Update Successfully !");
                }
                else
                {
                    MessageBox.Show("Field Empty!");
                }
                ClearField();
                LoadVatAndCharge();
            }
        }



        private void buttonRefresh_Click_1(object sender, EventArgs e)
        {
            ClearField();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
