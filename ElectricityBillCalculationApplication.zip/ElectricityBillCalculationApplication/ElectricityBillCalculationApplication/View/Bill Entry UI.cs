﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ElectricityBillCalculationApplication.Model;
using ElectricityBillCalculationApplication.View;

namespace ElectricityBillCalculationApplication
{
    public partial class BillEntry : Form
    {
        public BillEntry()
        {
            InitializeComponent();
            LoadTanentInfo();
            LoadUnitCostAndVat();
        
        }

        private void LoadUnitCostAndVat()
        {
            List<UnitPrice> unitPriceList = new List<UnitPrice>();
            UnitPrice aUnitPrice = new UnitPrice();

            unitPriceList = aUnitPrice.UnitCost();
            foreach (var u in unitPriceList)
            {
                labelUnitCostTill75.Text = u.UnitCostTill75.ToString();
                labelUnitCostTill200.Text = u.UnitCostTill200.ToString();
                labelUnitCostTill300.Text = u.UnitCostTill300.ToString();
                labelUnitCostTill400.Text = u.UnitCostTill400.ToString();
                labelUnitCostTill600.Text = u.UnitCostTill600.ToString();
                labelUnitCostMoreThan600.Text = u.UnitCostMoreThan600.ToString();
            }
            //Vat Load
            List<VatAndCharge> vatAndChargeList = new List<VatAndCharge>();
            VatAndCharge aVatAndCharge = new VatAndCharge();
            vatAndChargeList = aVatAndCharge.VatCharge();

            foreach (var v in vatAndChargeList)
            {
                labelVatPercentage.Text = v.VatPercentage.ToString() +" % " ;
            }
        }


        ElectricityCalculator aElectricityCalculator = new ElectricityCalculator();
       
        private void LoadTanentInfo()
        {
            TanentInfo aTanentInfo = new TanentInfo();

            comboBoxFlat.DisplayMember = "Flat";
            comboBoxFlat.ValueMember = "TanentID";
            comboBoxFlat.DataSource = aTanentInfo.Tanent().Tables[0];

            comboBoxFlat.SelectedIndex = -1;

            dateTimePickerPrevious.Format = DateTimePickerFormat.Custom;
            dateTimePickerPrevious.CustomFormat = "dd MMMM yyyy";
            dateTimePickerRecent.Format = DateTimePickerFormat.Custom;
            dateTimePickerRecent.CustomFormat = "dd MMMM yyyy";
            
                       
        }

        private void buttonEntryUnitAdd_Click(object sender, EventArgs e)
        {

            if (!string.IsNullOrEmpty(textBoxPresentUnit.Text) && !string.IsNullOrEmpty(textBoxPreviousUnit.Text) && !string.IsNullOrEmpty(comboBoxFlat.Text) )
            {
                dateTimePickerPrevious.Format = DateTimePickerFormat.Custom;
                dateTimePickerPrevious.CustomFormat = "dd MMMM yyyy";
                dateTimePickerRecent.Format = DateTimePickerFormat.Custom;
                dateTimePickerRecent.CustomFormat = "dd MMMM yyyy";

                
                aElectricityCalculator.PresentUnit = Convert.ToInt32(textBoxPresentUnit.Text);
                aElectricityCalculator.PreviousUnit = Convert.ToInt32(textBoxPreviousUnit.Text);
                textBoxTotalUnit.Text = Convert.ToString(aElectricityCalculator.TotalUnit());

      //Charge And Vat Load
                List<VatAndCharge> vatAndChargeList = new List<VatAndCharge>();
                VatAndCharge aVatAndCharge = new VatAndCharge ();
                vatAndChargeList = aVatAndCharge.VatCharge();

                foreach (var v in vatAndChargeList)
                {
                     aElectricityCalculator.ServiceCharge = v.ServiceCharge;
                     aElectricityCalculator.DemandCharge = v.DemandCharge;
                     aElectricityCalculator.VatPercentage = v.VatPercentage;
                }

     // Unit Cost Load
                List<UnitPrice> unitPriceList = new List<UnitPrice>();
                UnitPrice aUnitPrice = new UnitPrice();

                unitPriceList = aUnitPrice.UnitCost();
                foreach (var u in unitPriceList)
                {
                    aElectricityCalculator.UnitCostTill75 = u.UnitCostTill75;
                    aElectricityCalculator.UnitCostTill200 = u.UnitCostTill200;
                    aElectricityCalculator.UnitCostTill300 = u.UnitCostTill300;
                    aElectricityCalculator.UnitCostTill400 = u.UnitCostTill400;
                    aElectricityCalculator.UnitCostTill600 = u.UnitCostTill600;
                    
                }

                aElectricityCalculator.TanentID = Convert.ToInt32(comboBoxFlat.SelectedValue);


                MonthInfo aMonthInfo = new MonthInfo();
                aMonthInfo.DateFrom = dateTimePickerPrevious.Text;
                aMonthInfo.DateTo = dateTimePickerRecent.Text;
                dateTimePickerPrevious.Format = DateTimePickerFormat.Custom;
                dateTimePickerPrevious.CustomFormat = "MMMM yyyy";
                aMonthInfo.MonthName = dateTimePickerPrevious.Text;


                aElectricityCalculator.Date = dateTimePickerPrevious.Text;
         // Insert Bill To database
                aElectricityCalculator.AddBill();

        // Insrt Month 
                aMonthInfo.BillId = aMonthInfo.BillID(Convert.ToInt32(comboBoxFlat.SelectedValue));
                aMonthInfo.AddMonth();

                TotalPaybleBillForm();

                dateTimePickerPrevious.Format = DateTimePickerFormat.Custom;
                dateTimePickerPrevious.CustomFormat = "dd MMMM yyyy";


                
            }

            else if (Convert.ToInt32(textBoxPreviousUnit.Text) > Convert.ToInt32(textBoxPresentUnit.Text))
            {
                MessageBox.Show("Previous Unit can't be Grater than Present Unit.");
                textBoxPresentUnit.Text = "";
                textBoxPreviousUnit.Text = "";
            }
            else
            {
                MessageBox.Show("Field Can not be Empty!.");
               
            }
        }

        private void TotalPaybleBillForm()
        {

            PreviewBill aPreviewBill = new PreviewBill();

            dateTimePickerPrevious.Format = DateTimePickerFormat.Custom;
            dateTimePickerPrevious.CustomFormat = "MMMM yyyy";
            aPreviewBill.MonthName = dateTimePickerPrevious.Text;
            aPreviewBill.TanentId = Convert.ToInt32(comboBoxFlat.SelectedValue);

            List<PreviewBill> previewBillList = new List<PreviewBill>();
            previewBillList = aPreviewBill.BillPreview();

            foreach (var i in previewBillList)
            {
                labelDate.Text = (i.DateFrom + "  To  " + i.DateTo).ToString();
                labelMonth.Text = i.MonthName.ToString();

                labelName.Text = i.TanentName.ToString();
                labelFlat.Text = i.Flat.ToString();
                labelMeterNo.Text = i.MeterNo.ToString();

                labelPresentUnit.Text = i.PresentUnit.ToString();
                labelPreviousUnit.Text = i.PreviousUnit.ToString();
                labelTotalUnit.Text = i.TotalUnit.ToString();
                labelUnitBill.Text = i.UnitBill.ToString();
                labelServiceCharge.Text = i.ServiceCharge.ToString();
                labelDemandCharge.Text = i.DemandCharge.ToString();
                labelVat.Text = i.Vat.ToString();
                labelTotalPayble.Text = i.TotalPayble.ToString();

          // Insert Payment Table
                BillPayment aBillPayment = new BillPayment();
                aBillPayment.BillId = i.BillId;
                aBillPayment.Pay = 0;
                aBillPayment.TotalPayble = Convert.ToDouble(labelTotalPayble.Text);               
                aBillPayment.PaymentDate = DateTime.Now.ToString();
                aBillPayment.AddPayment();

            }
            
        }

        private void buttonEntryUnitRefresh_Click(object sender, EventArgs e)
        {
            textBoxPresentUnit.Text = "";
            textBoxPreviousUnit.Text = "";
            textBoxTotalUnit.Text = "";
            comboBoxFlat.SelectedIndex = -1;
           

            labelDate.Text = "";
            labelMonth.Text = "";
            labelMeterNo.Text = "";
            labelName.Text = "";
            labelFlat.Text = "";
            labelPresentUnit.Text = "" ;
            labelPreviousUnit.Text =
            labelTotalUnit.Text = "";
            labelUnitBill.Text = "";
            labelServiceCharge.Text = "";
            labelDemandCharge.Text = "";
            labelVat.Text = "";
            labelTotalPayble.Text = "";

        }

        private void buttonPreviewBill_Click(object sender, EventArgs e)
        {
            PreviewBillUI aPreviewBillUI = new PreviewBillUI();
            aPreviewBillUI.ShowDialog();
            
        }

        private void buttonPaymentBill_Click(object sender, EventArgs e)
        {
            BillPaymentUI aBillPayment = new BillPaymentUI();
            aBillPayment.ShowDialog();
        }

        private void buttonAddTanentInfo_Click(object sender, EventArgs e)
        {
            AddTanentInfoUI aTanentInfo = new AddTanentInfoUI();
            aTanentInfo.ShowDialog();
        }

        private void buttonUpdateTanentInfo_Click(object sender, EventArgs e)
        {
            UpdateTanentInfoUI aUpdateTanentInfo = new UpdateTanentInfoUI();
            aUpdateTanentInfo.ShowDialog();
        }

        private void buttonDuePayment_Click(object sender, EventArgs e)
        {
            DuePaymentUI aDuePayment = new DuePaymentUI();
            aDuePayment.ShowDialog();
        }

        private void buttonSetUnitPrice_Click(object sender, EventArgs e)
        {
            SetUnitPriceUI aSetUnitPrice = new SetUnitPriceUI();
            aSetUnitPrice.ShowDialog();
        }

        private void buttonUpdateUnitPrice_Click(object sender, EventArgs e)
        {
            UpdateUnitPriceUI aUpdateUnitPrice = new UpdateUnitPriceUI();
            aUpdateUnitPrice.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            SetVatAndChargeUI aSetVatAndCharge = new SetVatAndChargeUI();
            aSetVatAndCharge.ShowDialog();
        }

        private void buttonUpdateVatAndCharge_Click(object sender, EventArgs e)
        {
            UpdateVatAndChargeUI aUpdateVatAndCharge = new UpdateVatAndChargeUI();
            aUpdateVatAndCharge.ShowDialog();
        }

        private void buttonPrintBill_Click(object sender, EventArgs e)
        {

        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void comboBoxFlat_SelectedIndexChanged(object sender, EventArgs e)
        {
            TanentInfo aTanentInfo = new TanentInfo();
            comboBoxFlat.AutoCompleteSource = AutoCompleteSource.CustomSource;
            comboBoxFlat.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
            AutoCompleteStringCollection a = new AutoCompleteStringCollection();
            a.Add(aTanentInfo.Tanent().Tables[0].Rows[0][1].ToString());
            comboBoxFlat.AutoCompleteCustomSource = a;
        }

        //auto complete tptal unit
        private void comboBoxFlat_MouseClick(object sender, MouseEventArgs e)
        {
            if (!string.IsNullOrEmpty(textBoxPresentUnit.Text) && !string.IsNullOrEmpty(textBoxPreviousUnit.Text))
            {
                if (Convert.ToDouble(textBoxPresentUnit.Text) >= Convert.ToDouble(textBoxPreviousUnit.Text))
                {
                    aElectricityCalculator.PresentUnit = Convert.ToInt32(textBoxPresentUnit.Text);
                    aElectricityCalculator.PreviousUnit = Convert.ToInt32(textBoxPreviousUnit.Text);
                    textBoxTotalUnit.Text = Convert.ToString(aElectricityCalculator.TotalUnit());
                }
                else
                {
                    MessageBox.Show("Previous unit can not be grater than Present Unit");
                    textBoxPresentUnit.Text = "";
                    textBoxPreviousUnit.Text = "";
                }
            }
            else
            {
                MessageBox.Show("Empty Unit Field !");

            }

           
        }

        private void buttonSearch_Click(object sender, EventArgs e)
        {
            SearchUI aSearch = new SearchUI();
            aSearch.ShowDialog();
        }


        private void textBoxName_Click(object sender, EventArgs e)
        {
            TanentInfo aTanentInfo = new TanentInfo();
            List<TanentInfo> tanentInfoList = new List<TanentInfo>();
            tanentInfoList = aTanentInfo.Tanent(comboBoxFlat.Text);

            foreach (var i in tanentInfoList)
            {
                textBoxName.Text = i.TanentName;
            }
        }














    }
}
