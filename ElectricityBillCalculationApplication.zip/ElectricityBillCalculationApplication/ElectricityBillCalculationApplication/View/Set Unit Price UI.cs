﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ElectricityBillCalculationApplication.Model;

namespace ElectricityBillCalculationApplication.View
{
    public partial class SetUnitPriceUI : Form
    {
        public SetUnitPriceUI()
        {
            InitializeComponent();
        }

        private void buttonDone_Click(object sender, EventArgs e)
        {
            if( !string.IsNullOrEmpty(textBoxUnitCostTill75.Text) && !string.IsNullOrEmpty(textBoxUnitCostTill200.Text) && !string.IsNullOrEmpty(textBoxUnitCostTill300.Text)
                && !string.IsNullOrEmpty(textBoxUnitCostTill400.Text) && !string.IsNullOrEmpty(textBoxUnitCostTill600.Text) && !string.IsNullOrEmpty(textBoxUnitCostMoreThan600.Text))
            {
                UnitPrice aUnitPrice = new UnitPrice();
                aUnitPrice.UnitCostTill75 = Convert.ToDouble(textBoxUnitCostTill75.Text);
                aUnitPrice.UnitCostTill200 = Convert.ToDouble(textBoxUnitCostTill200.Text);
                aUnitPrice.UnitCostTill300 = Convert.ToDouble(textBoxUnitCostTill300.Text);
                aUnitPrice.UnitCostTill400 = Convert.ToDouble(textBoxUnitCostTill400.Text);
                aUnitPrice.UnitCostTill600 = Convert.ToDouble(textBoxUnitCostTill600.Text);
                aUnitPrice.UnitCostMoreThan600 = Convert.ToDouble(textBoxUnitCostMoreThan600.Text);
                aUnitPrice.AddUnitPrice();
                MessageBox.Show("Add Successfully !");
                ClearField();
            }
            else
            {
                MessageBox.Show("Empty Field !");
            }
           
        }

        private void ClearField()
        {
            textBoxUnitCostTill75.Text = "";
            textBoxUnitCostTill200.Text = "";
            textBoxUnitCostTill300.Text = "";
            textBoxUnitCostTill400.Text = "";
            textBoxUnitCostTill600.Text = "";
            textBoxUnitCostMoreThan600.Text = "";
        }

        private void buttonClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
