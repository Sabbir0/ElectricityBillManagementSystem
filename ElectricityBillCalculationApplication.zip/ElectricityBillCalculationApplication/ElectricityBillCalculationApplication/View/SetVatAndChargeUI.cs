﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ElectricityBillCalculationApplication.Model;

namespace ElectricityBillCalculationApplication.View
{
    public partial class SetVatAndChargeUI : Form
    {
        public SetVatAndChargeUI()
        {
            InitializeComponent();
        }

        private void buttonRefresh_Click(object sender, EventArgs e)
        {
            ClearField();
        }

        private void ClearField()
        {
            textBoxServiceCharge.Text = "";
            textBoxDemandCharge.Text = "";
            textBoxVat.Text = "";
        }

        private void buttonDone_Click(object sender, EventArgs e)
        {
            VatAndCharge aVatAndCharge = new VatAndCharge();
            aVatAndCharge.ServiceCharge = Convert.ToDouble( textBoxServiceCharge.Text);
            aVatAndCharge.DemandCharge = Convert.ToDouble(textBoxDemandCharge.Text);
            aVatAndCharge.VatPercentage = Convert.ToDouble(textBoxVat.Text);
            aVatAndCharge.AddVatAndCharge();

            MessageBox.Show("Add Successfully!");
            ClearField();
        }

        private void buttonClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
