﻿namespace ElectricityBillCalculationApplication.View
{
    partial class UpdateUnitPriceUI
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonClose = new System.Windows.Forms.Button();
            this.buttonRefresh = new System.Windows.Forms.Button();
            this.textBoxUnitCostMoreThan600 = new System.Windows.Forms.TextBox();
            this.textBoxUnitCostTill600 = new System.Windows.Forms.TextBox();
            this.textBoxUnitCostTill400 = new System.Windows.Forms.TextBox();
            this.textBoxUnitCostTill300 = new System.Windows.Forms.TextBox();
            this.textBoxUnitCostTill200 = new System.Windows.Forms.TextBox();
            this.textBoxUnitCostTill75 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.buttonUnitCostTill75Update = new System.Windows.Forms.Button();
            this.buttonUnitCostTill300Update = new System.Windows.Forms.Button();
            this.buttonUnitCostMoreThan600Update = new System.Windows.Forms.Button();
            this.buttonUnitCostTill200Update = new System.Windows.Forms.Button();
            this.buttonUnitCostTill400Update = new System.Windows.Forms.Button();
            this.buttonUnitCostTill600Update = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.dataGridViewUnitPrice = new System.Windows.Forms.DataGridView();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewUnitPrice)).BeginInit();
            this.SuspendLayout();
            // 
            // buttonClose
            // 
            this.buttonClose.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.buttonClose.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonClose.Location = new System.Drawing.Point(638, 251);
            this.buttonClose.Name = "buttonClose";
            this.buttonClose.Size = new System.Drawing.Size(101, 25);
            this.buttonClose.TabIndex = 15;
            this.buttonClose.Text = "Close";
            this.buttonClose.UseVisualStyleBackColor = false;
            this.buttonClose.Click += new System.EventHandler(this.buttonClose_Click);
            // 
            // buttonRefresh
            // 
            this.buttonRefresh.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.buttonRefresh.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonRefresh.Location = new System.Drawing.Point(745, 251);
            this.buttonRefresh.Name = "buttonRefresh";
            this.buttonRefresh.Size = new System.Drawing.Size(105, 25);
            this.buttonRefresh.TabIndex = 16;
            this.buttonRefresh.Text = "Refresh";
            this.buttonRefresh.UseVisualStyleBackColor = false;
            this.buttonRefresh.Click += new System.EventHandler(this.buttonRefresh_Click);
            // 
            // textBoxUnitCostMoreThan600
            // 
            this.textBoxUnitCostMoreThan600.Location = new System.Drawing.Point(202, 77);
            this.textBoxUnitCostMoreThan600.Name = "textBoxUnitCostMoreThan600";
            this.textBoxUnitCostMoreThan600.Size = new System.Drawing.Size(111, 20);
            this.textBoxUnitCostMoreThan600.TabIndex = 9;
            // 
            // textBoxUnitCostTill600
            // 
            this.textBoxUnitCostTill600.Location = new System.Drawing.Point(202, 72);
            this.textBoxUnitCostTill600.Name = "textBoxUnitCostTill600";
            this.textBoxUnitCostTill600.Size = new System.Drawing.Size(111, 20);
            this.textBoxUnitCostTill600.TabIndex = 10;
            // 
            // textBoxUnitCostTill400
            // 
            this.textBoxUnitCostTill400.Location = new System.Drawing.Point(202, 42);
            this.textBoxUnitCostTill400.Name = "textBoxUnitCostTill400";
            this.textBoxUnitCostTill400.Size = new System.Drawing.Size(111, 20);
            this.textBoxUnitCostTill400.TabIndex = 11;
            // 
            // textBoxUnitCostTill300
            // 
            this.textBoxUnitCostTill300.Location = new System.Drawing.Point(202, 46);
            this.textBoxUnitCostTill300.Name = "textBoxUnitCostTill300";
            this.textBoxUnitCostTill300.Size = new System.Drawing.Size(111, 20);
            this.textBoxUnitCostTill300.TabIndex = 12;
            // 
            // textBoxUnitCostTill200
            // 
            this.textBoxUnitCostTill200.Location = new System.Drawing.Point(202, 11);
            this.textBoxUnitCostTill200.Name = "textBoxUnitCostTill200";
            this.textBoxUnitCostTill200.Size = new System.Drawing.Size(111, 20);
            this.textBoxUnitCostTill200.TabIndex = 13;
            // 
            // textBoxUnitCostTill75
            // 
            this.textBoxUnitCostTill75.Location = new System.Drawing.Point(202, 17);
            this.textBoxUnitCostTill75.Name = "textBoxUnitCostTill75";
            this.textBoxUnitCostTill75.Size = new System.Drawing.Size(111, 20);
            this.textBoxUnitCostTill75.TabIndex = 14;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(13, 78);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(178, 15);
            this.label6.TabIndex = 3;
            this.label6.Text = "Unit Cost More Than 600 : ";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(62, 72);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(129, 15);
            this.label5.TabIndex = 4;
            this.label5.Text = "Unit Cost Till 600 : ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(62, 44);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(129, 15);
            this.label4.TabIndex = 5;
            this.label4.Text = "Unit Cost Till 400 : ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(58, 47);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(133, 15);
            this.label3.TabIndex = 6;
            this.label3.Text = "Unit Cost Till 300  : ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(62, 12);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(129, 15);
            this.label2.TabIndex = 7;
            this.label2.Text = "Unit Cost Till 200 : ";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(70, 17);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(121, 15);
            this.label1.TabIndex = 8;
            this.label1.Text = "Unit Cost Till 75 : ";
            // 
            // buttonUnitCostTill75Update
            // 
            this.buttonUnitCostTill75Update.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.buttonUnitCostTill75Update.Font = new System.Drawing.Font("Arial Unicode MS", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonUnitCostTill75Update.Location = new System.Drawing.Point(319, 17);
            this.buttonUnitCostTill75Update.Name = "buttonUnitCostTill75Update";
            this.buttonUnitCostTill75Update.Size = new System.Drawing.Size(82, 25);
            this.buttonUnitCostTill75Update.TabIndex = 15;
            this.buttonUnitCostTill75Update.Text = "Update";
            this.buttonUnitCostTill75Update.UseVisualStyleBackColor = false;
            this.buttonUnitCostTill75Update.Click += new System.EventHandler(this.buttonUnitCostTill75Update_Click);
            // 
            // buttonUnitCostTill300Update
            // 
            this.buttonUnitCostTill300Update.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.buttonUnitCostTill300Update.Font = new System.Drawing.Font("Arial Unicode MS", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonUnitCostTill300Update.Location = new System.Drawing.Point(319, 46);
            this.buttonUnitCostTill300Update.Name = "buttonUnitCostTill300Update";
            this.buttonUnitCostTill300Update.Size = new System.Drawing.Size(82, 25);
            this.buttonUnitCostTill300Update.TabIndex = 15;
            this.buttonUnitCostTill300Update.Text = "Update";
            this.buttonUnitCostTill300Update.UseVisualStyleBackColor = false;
            this.buttonUnitCostTill300Update.Click += new System.EventHandler(this.buttonUnitCostTill300Update_Click);
            // 
            // buttonUnitCostMoreThan600Update
            // 
            this.buttonUnitCostMoreThan600Update.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.buttonUnitCostMoreThan600Update.Font = new System.Drawing.Font("Arial Unicode MS", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonUnitCostMoreThan600Update.Location = new System.Drawing.Point(319, 78);
            this.buttonUnitCostMoreThan600Update.Name = "buttonUnitCostMoreThan600Update";
            this.buttonUnitCostMoreThan600Update.Size = new System.Drawing.Size(82, 25);
            this.buttonUnitCostMoreThan600Update.TabIndex = 15;
            this.buttonUnitCostMoreThan600Update.Text = "Update";
            this.buttonUnitCostMoreThan600Update.UseVisualStyleBackColor = false;
            this.buttonUnitCostMoreThan600Update.Click += new System.EventHandler(this.buttonUnitCostMoreThan600Update_Click);
            // 
            // buttonUnitCostTill200Update
            // 
            this.buttonUnitCostTill200Update.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.buttonUnitCostTill200Update.Font = new System.Drawing.Font("Arial Unicode MS", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonUnitCostTill200Update.Location = new System.Drawing.Point(319, 9);
            this.buttonUnitCostTill200Update.Name = "buttonUnitCostTill200Update";
            this.buttonUnitCostTill200Update.Size = new System.Drawing.Size(84, 25);
            this.buttonUnitCostTill200Update.TabIndex = 15;
            this.buttonUnitCostTill200Update.Text = "Update";
            this.buttonUnitCostTill200Update.UseVisualStyleBackColor = false;
            this.buttonUnitCostTill200Update.Click += new System.EventHandler(this.buttonUnitCostTill200Update_Click);
            // 
            // buttonUnitCostTill400Update
            // 
            this.buttonUnitCostTill400Update.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.buttonUnitCostTill400Update.Font = new System.Drawing.Font("Arial Unicode MS", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonUnitCostTill400Update.Location = new System.Drawing.Point(319, 41);
            this.buttonUnitCostTill400Update.Name = "buttonUnitCostTill400Update";
            this.buttonUnitCostTill400Update.Size = new System.Drawing.Size(84, 25);
            this.buttonUnitCostTill400Update.TabIndex = 15;
            this.buttonUnitCostTill400Update.Text = "Update";
            this.buttonUnitCostTill400Update.UseVisualStyleBackColor = false;
            this.buttonUnitCostTill400Update.Click += new System.EventHandler(this.buttonUnitCostTill400Update_Click);
            // 
            // buttonUnitCostTill600Update
            // 
            this.buttonUnitCostTill600Update.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.buttonUnitCostTill600Update.Font = new System.Drawing.Font("Arial Unicode MS", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonUnitCostTill600Update.Location = new System.Drawing.Point(319, 72);
            this.buttonUnitCostTill600Update.Name = "buttonUnitCostTill600Update";
            this.buttonUnitCostTill600Update.Size = new System.Drawing.Size(84, 25);
            this.buttonUnitCostTill600Update.TabIndex = 15;
            this.buttonUnitCostTill600Update.Text = "Update";
            this.buttonUnitCostTill600Update.UseVisualStyleBackColor = false;
            this.buttonUnitCostTill600Update.Click += new System.EventHandler(this.buttonUnitCostTill600Update_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.textBoxUnitCostTill75);
            this.panel1.Controls.Add(this.buttonUnitCostMoreThan600Update);
            this.panel1.Controls.Add(this.textBoxUnitCostTill300);
            this.panel1.Controls.Add(this.buttonUnitCostTill300Update);
            this.panel1.Controls.Add(this.textBoxUnitCostMoreThan600);
            this.panel1.Controls.Add(this.buttonUnitCostTill75Update);
            this.panel1.Location = new System.Drawing.Point(14, 136);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(416, 109);
            this.panel1.TabIndex = 17;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.buttonUnitCostTill600Update);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.buttonUnitCostTill400Update);
            this.panel2.Controls.Add(this.textBoxUnitCostTill200);
            this.panel2.Controls.Add(this.buttonUnitCostTill200Update);
            this.panel2.Controls.Add(this.textBoxUnitCostTill400);
            this.panel2.Controls.Add(this.textBoxUnitCostTill600);
            this.panel2.Location = new System.Drawing.Point(436, 136);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(414, 109);
            this.panel2.TabIndex = 18;
            // 
            // dataGridViewUnitPrice
            // 
            this.dataGridViewUnitPrice.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewUnitPrice.BackgroundColor = System.Drawing.SystemColors.ActiveCaption;
            this.dataGridViewUnitPrice.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewUnitPrice.Location = new System.Drawing.Point(30, 22);
            this.dataGridViewUnitPrice.Name = "dataGridViewUnitPrice";
            this.dataGridViewUnitPrice.Size = new System.Drawing.Size(809, 108);
            this.dataGridViewUnitPrice.TabIndex = 0;
            // 
            // UpdateUnitPriceUI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(869, 296);
            this.Controls.Add(this.dataGridViewUnitPrice);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.buttonClose);
            this.Controls.Add(this.buttonRefresh);
            this.Name = "UpdateUnitPriceUI";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Update Unit Price";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewUnitPrice)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button buttonClose;
        private System.Windows.Forms.Button buttonRefresh;
        private System.Windows.Forms.TextBox textBoxUnitCostMoreThan600;
        private System.Windows.Forms.TextBox textBoxUnitCostTill600;
        private System.Windows.Forms.TextBox textBoxUnitCostTill400;
        private System.Windows.Forms.TextBox textBoxUnitCostTill300;
        private System.Windows.Forms.TextBox textBoxUnitCostTill200;
        private System.Windows.Forms.TextBox textBoxUnitCostTill75;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button buttonUnitCostTill75Update;
        private System.Windows.Forms.Button buttonUnitCostTill300Update;
        private System.Windows.Forms.Button buttonUnitCostMoreThan600Update;
        private System.Windows.Forms.Button buttonUnitCostTill200Update;
        private System.Windows.Forms.Button buttonUnitCostTill400Update;
        private System.Windows.Forms.Button buttonUnitCostTill600Update;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.DataGridView dataGridViewUnitPrice;
    }
}