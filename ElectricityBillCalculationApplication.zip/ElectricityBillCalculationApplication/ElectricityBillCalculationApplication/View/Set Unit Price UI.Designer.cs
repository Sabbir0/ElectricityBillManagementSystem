﻿namespace ElectricityBillCalculationApplication.View
{
    partial class SetUnitPriceUI
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.textBoxUnitCostTill75 = new System.Windows.Forms.TextBox();
            this.textBoxUnitCostTill200 = new System.Windows.Forms.TextBox();
            this.textBoxUnitCostTill300 = new System.Windows.Forms.TextBox();
            this.textBoxUnitCostTill400 = new System.Windows.Forms.TextBox();
            this.textBoxUnitCostTill600 = new System.Windows.Forms.TextBox();
            this.textBoxUnitCostMoreThan600 = new System.Windows.Forms.TextBox();
            this.buttonDone = new System.Windows.Forms.Button();
            this.buttonClose = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(88, 37);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(121, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "Unit Cost Till 75 : ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(368, 38);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(129, 15);
            this.label2.TabIndex = 0;
            this.label2.Text = "Unit Cost Till 200 : ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(76, 67);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(133, 15);
            this.label3.TabIndex = 0;
            this.label3.Text = "Unit Cost Till 300  : ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(368, 70);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(129, 15);
            this.label4.TabIndex = 0;
            this.label4.Text = "Unit Cost Till 400 : ";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(368, 98);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(129, 15);
            this.label5.TabIndex = 0;
            this.label5.Text = "Unit Cost Till 600 : ";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(31, 98);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(178, 15);
            this.label6.TabIndex = 0;
            this.label6.Text = "Unit Cost More Than 600 : ";
            // 
            // textBoxUnitCostTill75
            // 
            this.textBoxUnitCostTill75.Location = new System.Drawing.Point(220, 37);
            this.textBoxUnitCostTill75.Name = "textBoxUnitCostTill75";
            this.textBoxUnitCostTill75.Size = new System.Drawing.Size(111, 20);
            this.textBoxUnitCostTill75.TabIndex = 1;
            // 
            // textBoxUnitCostTill200
            // 
            this.textBoxUnitCostTill200.Location = new System.Drawing.Point(508, 37);
            this.textBoxUnitCostTill200.Name = "textBoxUnitCostTill200";
            this.textBoxUnitCostTill200.Size = new System.Drawing.Size(111, 20);
            this.textBoxUnitCostTill200.TabIndex = 4;
            // 
            // textBoxUnitCostTill300
            // 
            this.textBoxUnitCostTill300.Location = new System.Drawing.Point(220, 66);
            this.textBoxUnitCostTill300.Name = "textBoxUnitCostTill300";
            this.textBoxUnitCostTill300.Size = new System.Drawing.Size(111, 20);
            this.textBoxUnitCostTill300.TabIndex = 2;
            // 
            // textBoxUnitCostTill400
            // 
            this.textBoxUnitCostTill400.Location = new System.Drawing.Point(508, 68);
            this.textBoxUnitCostTill400.Name = "textBoxUnitCostTill400";
            this.textBoxUnitCostTill400.Size = new System.Drawing.Size(111, 20);
            this.textBoxUnitCostTill400.TabIndex = 5;
            // 
            // textBoxUnitCostTill600
            // 
            this.textBoxUnitCostTill600.Location = new System.Drawing.Point(508, 98);
            this.textBoxUnitCostTill600.Name = "textBoxUnitCostTill600";
            this.textBoxUnitCostTill600.Size = new System.Drawing.Size(111, 20);
            this.textBoxUnitCostTill600.TabIndex = 6;
            // 
            // textBoxUnitCostMoreThan600
            // 
            this.textBoxUnitCostMoreThan600.Location = new System.Drawing.Point(220, 97);
            this.textBoxUnitCostMoreThan600.Name = "textBoxUnitCostMoreThan600";
            this.textBoxUnitCostMoreThan600.Size = new System.Drawing.Size(111, 20);
            this.textBoxUnitCostMoreThan600.TabIndex = 3;
            // 
            // buttonDone
            // 
            this.buttonDone.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.buttonDone.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonDone.Location = new System.Drawing.Point(544, 129);
            this.buttonDone.Name = "buttonDone";
            this.buttonDone.Size = new System.Drawing.Size(75, 25);
            this.buttonDone.TabIndex = 8;
            this.buttonDone.Text = "Done";
            this.buttonDone.UseVisualStyleBackColor = false;
            this.buttonDone.Click += new System.EventHandler(this.buttonDone_Click);
            // 
            // buttonClose
            // 
            this.buttonClose.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.buttonClose.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonClose.Location = new System.Drawing.Point(463, 129);
            this.buttonClose.Name = "buttonClose";
            this.buttonClose.Size = new System.Drawing.Size(75, 25);
            this.buttonClose.TabIndex = 7;
            this.buttonClose.Text = "Close";
            this.buttonClose.UseVisualStyleBackColor = false;
            this.buttonClose.Click += new System.EventHandler(this.buttonClose_Click);
            // 
            // SetUnitPriceUI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(669, 177);
            this.Controls.Add(this.buttonClose);
            this.Controls.Add(this.buttonDone);
            this.Controls.Add(this.textBoxUnitCostMoreThan600);
            this.Controls.Add(this.textBoxUnitCostTill600);
            this.Controls.Add(this.textBoxUnitCostTill400);
            this.Controls.Add(this.textBoxUnitCostTill300);
            this.Controls.Add(this.textBoxUnitCostTill200);
            this.Controls.Add(this.textBoxUnitCostTill75);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "SetUnitPriceUI";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "SetUnitPriceUI";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBoxUnitCostTill75;
        private System.Windows.Forms.TextBox textBoxUnitCostTill200;
        private System.Windows.Forms.TextBox textBoxUnitCostTill300;
        private System.Windows.Forms.TextBox textBoxUnitCostTill400;
        private System.Windows.Forms.TextBox textBoxUnitCostTill600;
        private System.Windows.Forms.TextBox textBoxUnitCostMoreThan600;
        private System.Windows.Forms.Button buttonDone;
        private System.Windows.Forms.Button buttonClose;
    }
}