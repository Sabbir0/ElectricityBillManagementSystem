﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ElectricityBillCalculationApplication.Model;

namespace ElectricityBillCalculationApplication.View
{
    public partial class AddTanentInfoUI : Form
    {
        public AddTanentInfoUI()
        {
            InitializeComponent();
        }
        public void ClearTextBoxData()
        {
            textBoxName.Text = "";
            textBoxFlat.Text = "";
            textBoxMeterNo.Text = "";
        }
        private void buttonAddTanent_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBoxFlat.Text) && !string.IsNullOrEmpty(textBoxName.Text) && !string.IsNullOrEmpty(textBoxMeterNo.Text))
            {
                TanentInfo aTanentInfo = new TanentInfo();
                aTanentInfo.TanentName = textBoxName.Text;
                aTanentInfo.Flat = textBoxFlat.Text;
                aTanentInfo.MeterNo = textBoxMeterNo.Text;
                aTanentInfo.AddTanentInfo();

                MessageBox.Show("Add Successfully!");
                ClearTextBoxData();
            }
            else
            {
                MessageBox.Show("Empty Field !");
            }
            
        }

        private void buttonClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

    }
}
