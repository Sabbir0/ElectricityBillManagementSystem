﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ElectricityBillCalculationApplication.Model;

namespace ElectricityBillCalculationApplication.View
{
    public partial class AdjustDueButtonUI : Form
    {
        public AdjustDueButtonUI()
        {
            InitializeComponent();
            
        }

        public int _billId = 0;
        public double _pay = 0;
        public double _due = 0;
       

        


        private void buttonDone_Click(object sender, EventArgs e)
        {
            AdjustDueButtton aAdjustDueButton = new AdjustDueButtton();
            
            aAdjustDueButton.BillId = _billId;
            aAdjustDueButton.Pay = _pay;
            aAdjustDueButton.PreviousDue = _due;
            aAdjustDueButton.AdjustedDue = Convert.ToDouble(textBoxPay.Text);
            aAdjustDueButton.UpdateDue();
            MessageBox.Show("Sabbir");
        }
   
        private void buttonClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }




    }





    }

