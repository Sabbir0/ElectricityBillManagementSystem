﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ElectricityBillCalculationApplication.Model;



namespace ElectricityBillCalculationApplication.View
{
    public partial class PreviewBillUI : Form
    {
        public PreviewBillUI()
        {
            InitializeComponent();
            LoadBillDetails();
        }

        PreviewBill aPreviewBill = new PreviewBill();

        private void LoadBillDetails()
        {
            TanentInfo aTanentInfo = new TanentInfo();

            comboBoxFlat.DisplayMember = "Flat";
            comboBoxFlat.ValueMember = "TanentID";
            comboBoxFlat.DataSource = aTanentInfo.Tanent().Tables[0];

            MonthInfo aMonthInfo = new MonthInfo();
           
           // comboBoxDate.DisplayMember = "MonthName";
           // comboBoxDate.ValueMember = "MonthID";
            //comboBoxDate.DataSource = aMonthInfo.Month().Tables[0];

            comboBoxDate.SelectedIndex = -1;
            comboBoxFlat.SelectedIndex = -1;

          
        }

    // Done Button
        private void buttonDone_Click(object sender, EventArgs e)
        {
            PreviewBillForm();
        }

   //Refresh Button
        private void buttonRefresh_Click(object sender, EventArgs e)
        {
            comboBoxDate.SelectedIndex = -1;
            textBoxName.Text = "";
            comboBoxFlat.SelectedIndex = -1;
            textBoxYear.Text = "";

            labelPay.Text = "";
            labelDue.Text = "";
            textBoxAdjustDue.Text = "";

            labelDate.Text = "";
            labelMonth.Text = "";
            labelMeterNo.Text = "";
            labelName.Text = "";
            labelFlat.Text = "";
            labelPresentUnit.Text = "";
            labelPreviousUnit.Text =
            labelTotalUnit.Text = "";
            labelUnitBill.Text = "";
            labelServiceCharge.Text = "";
            labelDemandCharge.Text = "";
            labelVat.Text = "";
            labelTotalPayble.Text = "";
        }
        private void PreviewBillForm()
        {
            PreviewBill aPreviewBill = new PreviewBill();

            aPreviewBill.MonthName = comboBoxDate.Text + " " + textBoxYear.Text;
            aPreviewBill.TanentId = Convert.ToInt32(comboBoxFlat.SelectedValue);

            List<PreviewBill> previewBillList = new List<PreviewBill>();
            previewBillList = aPreviewBill.BillPreview();

            foreach (var i in previewBillList)
            {
                labelDate.Text = (i.DateFrom + "  To  " + i.DateTo).ToString();
                labelMonth.Text = i.MonthName.ToString();
                
                labelName.Text = i.TanentName.ToString();
                labelFlat.Text = i.Flat.ToString();
                labelMeterNo.Text = i.MeterNo.ToString();

                labelPresentUnit.Text = i.PresentUnit.ToString();
                labelPreviousUnit.Text = i.PreviousUnit.ToString();
                labelTotalUnit.Text = i.TotalUnit.ToString();
                labelUnitBill.Text = i.UnitBill.ToString();
                labelServiceCharge.Text = i.ServiceCharge.ToString();
                labelDemandCharge.Text = i.DemandCharge.ToString();
                labelVat.Text = i.Vat.ToString();
                labelTotalPayble.Text = i.TotalPayble.ToString();

                PayDue aPayDue = new PayDue();
                List<PayDue> payDueList = new List<PayDue>();
                payDueList = aPayDue.PreviewPayDue(labelFlat.Text, labelMonth.Text);
                              
                    if ((payDueList != null) && (payDueList.Count() > 0) )
                    {
                        foreach (var m in payDueList)
                        {
                            labelPay.Text = m.Pay.ToString();
                            labelDue.Text = Math.Round(m.Due, 2, MidpointRounding.AwayFromZero).ToString();
                        }
                    }
                    else
                    {
                        labelPay.Text = "0";
                        labelDue.Text = labelTotalPayble.Text;
                    }
                    
                  

            }

        }

        private void buttonAdjustDue_Click(object sender, EventArgs e)
        {
            if( Convert.ToDouble(labelDue.Text) == Convert.ToDouble(labelTotalPayble.Text) )
            {             
                if (Convert.ToDouble(labelDue.Text) < Convert.ToDouble(textBoxAdjustDue.Text))
                {
                    MessageBox.Show("Payment can not be greater than Due!");
                }
                else 
                {
                    BillPayment aBillPayment = new BillPayment();

                    aBillPayment.Pay = Convert.ToDouble(textBoxAdjustDue.Text);
                    aBillPayment.TotalPayble = Convert.ToDouble(labelTotalPayble.Text);
                    aBillPayment.PaymentDate = Convert.ToString(DateTime.Now);

                    PreviewBill aPreviewBill = new PreviewBill();
                    aPreviewBill.MonthName = comboBoxDate.Text;
                    aPreviewBill.TanentId = Convert.ToInt32(comboBoxFlat.SelectedValue);
                    List<PreviewBill> previewBillList = new List<PreviewBill>();
                    previewBillList = aPreviewBill.BillPreview();

                    foreach (var i in previewBillList)
                    {
                        aBillPayment.BillId = i.BillId;
                    }

                    aBillPayment.AddPayment();
                    MessageBox.Show("Payment Add Successfully!");
                    labelPay.Text = textBoxAdjustDue.Text;
                    labelDue.Text = aBillPayment.DueCalculator().ToString();
                }               

            }
            else
            {
                if (Convert.ToDouble(labelDue.Text) < Convert.ToDouble(textBoxAdjustDue.Text))
                {
                    MessageBox.Show("Payment can not be greater than Due!");
                }
                else
                {
                    AdjustDue aAdjustDue = new AdjustDue();
                    aAdjustDue.BillId = aAdjustDue.BillID(comboBoxFlat.Text, comboBoxDate.Text);

                    aAdjustDue.AdjustedDue = Convert.ToDouble(textBoxAdjustDue.Text);
                    aAdjustDue.Pay = Convert.ToDouble(labelPay.Text);
                    aAdjustDue.PreviousDue = Convert.ToDouble(labelDue.Text);

                    aAdjustDue.UpdateDue();
                    MessageBox.Show("Due Update Successfully!");
                    textBoxAdjustDue.Text = "";
                    labelPay.Text = aAdjustDue.UpdatePay().ToString();
                    labelDue.Text = aAdjustDue.DueAdjust().ToString();
                }
               
            }
        }

        private void buttonClose_Click(object sender, EventArgs e)
        {
            this.Close(); 
        }

        private void textBoxName_Click(object sender, EventArgs e)
        {
            TanentInfo aTanentInfo = new TanentInfo();
            List<TanentInfo> tanentInfoList = new List<TanentInfo>();
            tanentInfoList = aTanentInfo.Tanent(comboBoxFlat.Text);

            foreach (var i in tanentInfoList)
            {
                textBoxName.Text = i.TanentName;
            }
        }













    }
}
