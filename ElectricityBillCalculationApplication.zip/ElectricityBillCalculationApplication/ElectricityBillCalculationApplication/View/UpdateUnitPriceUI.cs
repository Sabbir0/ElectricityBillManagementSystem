﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ElectricityBillCalculationApplication.Model;

namespace ElectricityBillCalculationApplication.View
{
    public partial class UpdateUnitPriceUI : Form
    {
        public UpdateUnitPriceUI()
        {
            InitializeComponent();
            LoadUnitPrice();
        }

        private void LoadUnitPrice()
        {
            List<UnitPrice> unitPriceList = new List<UnitPrice>();
            UnitPrice aUnitPrice = new UnitPrice();

            unitPriceList = aUnitPrice.UnitCost();
            dataGridViewUnitPrice.DataSource = unitPriceList;
            
        }

        private void buttonUnitCostTill75Update_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBoxUnitCostTill75.Text))
            {
                List<UnitPrice> unitPriceList = new List<UnitPrice>();
                UnitPrice aUnitPrice = new UnitPrice();

                unitPriceList = aUnitPrice.UnitCost();
                foreach (var i in unitPriceList)
                {
                    aUnitPrice.UnitPriceUpdate(i.UnitPriceId,
                                               Convert.ToDouble(textBoxUnitCostTill75.Text),
                                               i.UnitCostTill200,
                                               i.UnitCostTill300,
                                               i.UnitCostTill400,
                                               i.UnitCostTill600,
                                               i.UnitCostMoreThan600);
                    MessageBox.Show("Unit Cost Till 75 Updated Successfully!");
                    textBoxUnitCostTill75.Text = "";
                    LoadUnitPrice();
                }
            }
            else
            {
                MessageBox.Show("Field Empty!");
            }

        }

        private void buttonUnitCostTill200Update_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBoxUnitCostTill200.Text))
            {
                List<UnitPrice> unitPriceList = new List<UnitPrice>();
                UnitPrice aUnitPrice = new UnitPrice();

                unitPriceList = aUnitPrice.UnitCost();
                foreach (var i in unitPriceList)
                {
                    aUnitPrice.UnitPriceUpdate(i.UnitPriceId,
                                               i.UnitCostTill75,
                                               Convert.ToDouble(textBoxUnitCostTill200.Text),
                                               i.UnitCostTill300,
                                               i.UnitCostTill400,
                                               i.UnitCostTill600,
                                               i.UnitCostMoreThan600);
                    MessageBox.Show("Unit Cost Till 200 Updated Successfully!");
                    textBoxUnitCostTill200.Text = "";
                    LoadUnitPrice();
                }
            }
            else
            {
                MessageBox.Show("Field Empty!");
            }
            
        }

        private void buttonUnitCostTill300Update_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBoxUnitCostTill300.Text))
            {
                List<UnitPrice> unitPriceList = new List<UnitPrice>();
                UnitPrice aUnitPrice = new UnitPrice();

                unitPriceList = aUnitPrice.UnitCost();
                foreach (var i in unitPriceList)
                {
                    aUnitPrice.UnitPriceUpdate(i.UnitPriceId,
                                               i.UnitCostTill75,
                                               i.UnitCostTill200,
                                               Convert.ToDouble(textBoxUnitCostTill300.Text),
                                               i.UnitCostTill400,
                                               i.UnitCostTill600,
                                               i.UnitCostMoreThan600);
                    MessageBox.Show("Unit Cost Till 300 Updated Successfully!");
                    textBoxUnitCostTill300.Text = "";
                    LoadUnitPrice();
                }
            }
            else
            {
                MessageBox.Show("Field Empty!");
            }
           
        }

        private void buttonUnitCostTill400Update_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBoxUnitCostTill400.Text))
            {
                List<UnitPrice> unitPriceList = new List<UnitPrice>();
                UnitPrice aUnitPrice = new UnitPrice();

                unitPriceList = aUnitPrice.UnitCost();
                foreach (var i in unitPriceList)
                {
                    aUnitPrice.UnitPriceUpdate(i.UnitPriceId,
                                               i.UnitCostTill75,
                                               i.UnitCostTill200,
                                               i.UnitCostTill300,
                                               Convert.ToDouble(textBoxUnitCostTill400.Text),
                                               i.UnitCostTill600,
                                               i.UnitCostMoreThan600);
                    MessageBox.Show("Unit Cost Till 400 Updated Successfully!");
                    textBoxUnitCostTill400.Text = "";
                    LoadUnitPrice();
                }
            }
            else
            {
                MessageBox.Show("Field Empty!");
            }
           
        }

        private void buttonUnitCostTill600Update_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBoxUnitCostTill600.Text))
            {
                List<UnitPrice> unitPriceList = new List<UnitPrice>();
                UnitPrice aUnitPrice = new UnitPrice();

                unitPriceList = aUnitPrice.UnitCost();
                foreach (var i in unitPriceList)
                {
                    aUnitPrice.UnitPriceUpdate(i.UnitPriceId,
                                               i.UnitCostTill75,
                                               i.UnitCostTill200,
                                               i.UnitCostTill300,
                                               i.UnitCostTill400,
                                               Convert.ToDouble(textBoxUnitCostTill600.Text),
                                               i.UnitCostMoreThan600);
                    MessageBox.Show("Unit Cost Till 600 Updated Successfully!");
                    textBoxUnitCostTill600.Text = "";
                    LoadUnitPrice();
                }
            }
            else
            {
                MessageBox.Show("Field Empty!");
            }
           
        }

        private void buttonUnitCostMoreThan600Update_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBoxUnitCostMoreThan600.Text))
            {
                List<UnitPrice> unitPriceList = new List<UnitPrice>();
                UnitPrice aUnitPrice = new UnitPrice();

                unitPriceList = aUnitPrice.UnitCost();
                foreach (var i in unitPriceList)
                {
                    aUnitPrice.UnitPriceUpdate(i.UnitPriceId,
                                               i.UnitCostTill75,
                                               i.UnitCostTill200,
                                               i.UnitCostTill300,
                                               i.UnitCostTill400,
                                              i.UnitCostTill600,
                                               Convert.ToDouble(textBoxUnitCostMoreThan600.Text));
                    MessageBox.Show("Unit Cost More Than 600 Updated Successfully!");
                    textBoxUnitCostMoreThan600.Text = "";
                    LoadUnitPrice();
                }
            }
            else
            {
                MessageBox.Show("Field Empty!");
            }
           
            
        }

        private void buttonRefresh_Click(object sender, EventArgs e)
        {
            textBoxUnitCostTill75.Text = "";
            textBoxUnitCostTill200.Text = "";
            textBoxUnitCostTill300.Text = "";
            textBoxUnitCostTill400.Text = "";
            textBoxUnitCostTill600.Text = "";
            textBoxUnitCostMoreThan600.Text = "";
        }

        private void buttonClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }


    }
}
