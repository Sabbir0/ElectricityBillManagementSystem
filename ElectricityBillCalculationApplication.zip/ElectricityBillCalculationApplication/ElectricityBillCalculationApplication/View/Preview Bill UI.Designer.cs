﻿namespace ElectricityBillCalculationApplication.View
{
    partial class PreviewBillUI
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBoxPreviewBill = new System.Windows.Forms.GroupBox();
            this.labelDue = new System.Windows.Forms.Label();
            this.labelPay = new System.Windows.Forms.Label();
            this.labelDate = new System.Windows.Forms.Label();
            this.labelMeterNo = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.labelMonth = new System.Windows.Forms.Label();
            this.labelName = new System.Windows.Forms.Label();
            this.labelFlat = new System.Windows.Forms.Label();
            this.labelVat = new System.Windows.Forms.Label();
            this.labelDemandCharge = new System.Windows.Forms.Label();
            this.labelServiceCharge = new System.Windows.Forms.Label();
            this.labelUnitBill = new System.Windows.Forms.Label();
            this.labelTotalUnit = new System.Windows.Forms.Label();
            this.labelPreviousUnit = new System.Windows.Forms.Label();
            this.labelPresentUnit = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.buttonPrintBill = new System.Windows.Forms.Button();
            this.buttonClose = new System.Windows.Forms.Button();
            this.labelTotalPayble = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.buttonAdjustDue = new System.Windows.Forms.Button();
            this.textBoxAdjustDue = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.buttonRefresh = new System.Windows.Forms.Button();
            this.buttonDone = new System.Windows.Forms.Button();
            this.comboBoxFlat = new System.Windows.Forms.ComboBox();
            this.textBoxName = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.textBoxYear = new System.Windows.Forms.TextBox();
            this.comboBoxDate = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBoxPreviewBill.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(23, 96);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(67, 18);
            this.label1.TabIndex = 0;
            this.label1.Text = "Name : ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(23, 68);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(51, 18);
            this.label2.TabIndex = 1;
            this.label2.Text = "Flat : ";
            // 
            // groupBoxPreviewBill
            // 
            this.groupBoxPreviewBill.Controls.Add(this.labelDue);
            this.groupBoxPreviewBill.Controls.Add(this.labelPay);
            this.groupBoxPreviewBill.Controls.Add(this.labelDate);
            this.groupBoxPreviewBill.Controls.Add(this.labelMeterNo);
            this.groupBoxPreviewBill.Controls.Add(this.label5);
            this.groupBoxPreviewBill.Controls.Add(this.label6);
            this.groupBoxPreviewBill.Controls.Add(this.labelMonth);
            this.groupBoxPreviewBill.Controls.Add(this.labelName);
            this.groupBoxPreviewBill.Controls.Add(this.labelFlat);
            this.groupBoxPreviewBill.Controls.Add(this.labelVat);
            this.groupBoxPreviewBill.Controls.Add(this.labelDemandCharge);
            this.groupBoxPreviewBill.Controls.Add(this.labelServiceCharge);
            this.groupBoxPreviewBill.Controls.Add(this.labelUnitBill);
            this.groupBoxPreviewBill.Controls.Add(this.labelTotalUnit);
            this.groupBoxPreviewBill.Controls.Add(this.labelPreviousUnit);
            this.groupBoxPreviewBill.Controls.Add(this.labelPresentUnit);
            this.groupBoxPreviewBill.Controls.Add(this.label16);
            this.groupBoxPreviewBill.Controls.Add(this.label15);
            this.groupBoxPreviewBill.Controls.Add(this.label14);
            this.groupBoxPreviewBill.Controls.Add(this.label13);
            this.groupBoxPreviewBill.Controls.Add(this.label12);
            this.groupBoxPreviewBill.Controls.Add(this.label11);
            this.groupBoxPreviewBill.Controls.Add(this.label10);
            this.groupBoxPreviewBill.Controls.Add(this.label9);
            this.groupBoxPreviewBill.Controls.Add(this.label8);
            this.groupBoxPreviewBill.Controls.Add(this.label4);
            this.groupBoxPreviewBill.Controls.Add(this.label19);
            this.groupBoxPreviewBill.Controls.Add(this.label20);
            this.groupBoxPreviewBill.Controls.Add(this.buttonPrintBill);
            this.groupBoxPreviewBill.Controls.Add(this.buttonClose);
            this.groupBoxPreviewBill.Controls.Add(this.labelTotalPayble);
            this.groupBoxPreviewBill.Controls.Add(this.label17);
            this.groupBoxPreviewBill.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBoxPreviewBill.Location = new System.Drawing.Point(12, 133);
            this.groupBoxPreviewBill.Name = "groupBoxPreviewBill";
            this.groupBoxPreviewBill.Size = new System.Drawing.Size(829, 292);
            this.groupBoxPreviewBill.TabIndex = 11;
            this.groupBoxPreviewBill.TabStop = false;
            this.groupBoxPreviewBill.Text = "Total  Payble Bill";
            // 
            // labelDue
            // 
            this.labelDue.AutoSize = true;
            this.labelDue.Location = new System.Drawing.Point(184, 263);
            this.labelDue.Name = "labelDue";
            this.labelDue.Size = new System.Drawing.Size(0, 18);
            this.labelDue.TabIndex = 75;
            // 
            // labelPay
            // 
            this.labelPay.AutoSize = true;
            this.labelPay.Location = new System.Drawing.Point(184, 242);
            this.labelPay.Name = "labelPay";
            this.labelPay.Size = new System.Drawing.Size(0, 18);
            this.labelPay.TabIndex = 74;
            // 
            // labelDate
            // 
            this.labelDate.AutoSize = true;
            this.labelDate.Location = new System.Drawing.Point(196, 32);
            this.labelDate.Name = "labelDate";
            this.labelDate.Size = new System.Drawing.Size(0, 18);
            this.labelDate.TabIndex = 73;
            // 
            // labelMeterNo
            // 
            this.labelMeterNo.AutoSize = true;
            this.labelMeterNo.Location = new System.Drawing.Point(196, 79);
            this.labelMeterNo.Name = "labelMeterNo";
            this.labelMeterNo.Size = new System.Drawing.Size(0, 18);
            this.labelMeterNo.TabIndex = 72;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(135, 241);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(46, 18);
            this.label5.TabIndex = 1;
            this.label5.Text = "Pay :";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(132, 264);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(53, 18);
            this.label6.TabIndex = 1;
            this.label6.Text = "Due : ";
            // 
            // labelMonth
            // 
            this.labelMonth.AutoSize = true;
            this.labelMonth.Location = new System.Drawing.Point(195, 58);
            this.labelMonth.Name = "labelMonth";
            this.labelMonth.Size = new System.Drawing.Size(0, 18);
            this.labelMonth.TabIndex = 71;
            // 
            // labelName
            // 
            this.labelName.AutoSize = true;
            this.labelName.Location = new System.Drawing.Point(195, 101);
            this.labelName.Name = "labelName";
            this.labelName.Size = new System.Drawing.Size(0, 18);
            this.labelName.TabIndex = 70;
            // 
            // labelFlat
            // 
            this.labelFlat.AutoSize = true;
            this.labelFlat.Location = new System.Drawing.Point(197, 125);
            this.labelFlat.Name = "labelFlat";
            this.labelFlat.Size = new System.Drawing.Size(0, 18);
            this.labelFlat.TabIndex = 69;
            // 
            // labelVat
            // 
            this.labelVat.AutoSize = true;
            this.labelVat.Location = new System.Drawing.Point(649, 171);
            this.labelVat.Name = "labelVat";
            this.labelVat.Size = new System.Drawing.Size(0, 18);
            this.labelVat.TabIndex = 68;
            // 
            // labelDemandCharge
            // 
            this.labelDemandCharge.AutoSize = true;
            this.labelDemandCharge.Location = new System.Drawing.Point(648, 148);
            this.labelDemandCharge.Name = "labelDemandCharge";
            this.labelDemandCharge.Size = new System.Drawing.Size(0, 18);
            this.labelDemandCharge.TabIndex = 67;
            // 
            // labelServiceCharge
            // 
            this.labelServiceCharge.AutoSize = true;
            this.labelServiceCharge.Location = new System.Drawing.Point(647, 123);
            this.labelServiceCharge.Name = "labelServiceCharge";
            this.labelServiceCharge.Size = new System.Drawing.Size(0, 18);
            this.labelServiceCharge.TabIndex = 66;
            // 
            // labelUnitBill
            // 
            this.labelUnitBill.AutoSize = true;
            this.labelUnitBill.Location = new System.Drawing.Point(647, 102);
            this.labelUnitBill.Name = "labelUnitBill";
            this.labelUnitBill.Size = new System.Drawing.Size(0, 18);
            this.labelUnitBill.TabIndex = 65;
            // 
            // labelTotalUnit
            // 
            this.labelTotalUnit.AutoSize = true;
            this.labelTotalUnit.Location = new System.Drawing.Point(647, 78);
            this.labelTotalUnit.Name = "labelTotalUnit";
            this.labelTotalUnit.Size = new System.Drawing.Size(0, 18);
            this.labelTotalUnit.TabIndex = 64;
            // 
            // labelPreviousUnit
            // 
            this.labelPreviousUnit.AutoSize = true;
            this.labelPreviousUnit.Location = new System.Drawing.Point(197, 172);
            this.labelPreviousUnit.Name = "labelPreviousUnit";
            this.labelPreviousUnit.Size = new System.Drawing.Size(0, 18);
            this.labelPreviousUnit.TabIndex = 63;
            // 
            // labelPresentUnit
            // 
            this.labelPresentUnit.AutoSize = true;
            this.labelPresentUnit.Location = new System.Drawing.Point(197, 147);
            this.labelPresentUnit.Name = "labelPresentUnit";
            this.labelPresentUnit.Size = new System.Drawing.Size(0, 18);
            this.labelPresentUnit.TabIndex = 62;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(521, 174);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(53, 18);
            this.label16.TabIndex = 61;
            this.label16.Text = "VAT : ";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(522, 102);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(81, 18);
            this.label15.TabIndex = 60;
            this.label15.Text = "Unit Bill : ";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(522, 147);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(144, 18);
            this.label14.TabIndex = 59;
            this.label14.Text = "Demand Charge : ";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(521, 123);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(138, 18);
            this.label13.TabIndex = 58;
            this.label13.Text = "Service Charge : ";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(522, 76);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(96, 18);
            this.label12.TabIndex = 57;
            this.label12.Text = "Total Unit : ";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(71, 172);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(119, 18);
            this.label11.TabIndex = 56;
            this.label11.Text = "Previous Unit: ";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(71, 147);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(116, 18);
            this.label10.TabIndex = 55;
            this.label10.Text = "Present Unit : ";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(71, 124);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(51, 18);
            this.label9.TabIndex = 54;
            this.label9.Text = "Flat : ";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(71, 101);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(67, 18);
            this.label8.TabIndex = 53;
            this.label8.Text = "Name : ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(72, 32);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(58, 18);
            this.label4.TabIndex = 51;
            this.label4.Text = "Date : ";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(72, 79);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(93, 18);
            this.label19.TabIndex = 52;
            this.label19.Text = "Meter No : ";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(71, 58);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(70, 18);
            this.label20.TabIndex = 50;
            this.label20.Text = "Month : ";
            // 
            // buttonPrintBill
            // 
            this.buttonPrintBill.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonPrintBill.Location = new System.Drawing.Point(683, 207);
            this.buttonPrintBill.Name = "buttonPrintBill";
            this.buttonPrintBill.Size = new System.Drawing.Size(112, 36);
            this.buttonPrintBill.TabIndex = 23;
            this.buttonPrintBill.Text = "Print";
            this.buttonPrintBill.UseVisualStyleBackColor = true;
            // 
            // buttonClose
            // 
            this.buttonClose.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonClose.Location = new System.Drawing.Point(569, 207);
            this.buttonClose.Name = "buttonClose";
            this.buttonClose.Size = new System.Drawing.Size(108, 36);
            this.buttonClose.TabIndex = 22;
            this.buttonClose.Text = "Close";
            this.buttonClose.UseVisualStyleBackColor = true;
            this.buttonClose.Click += new System.EventHandler(this.buttonClose_Click);
            // 
            // labelTotalPayble
            // 
            this.labelTotalPayble.AutoSize = true;
            this.labelTotalPayble.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTotalPayble.Location = new System.Drawing.Point(177, 207);
            this.labelTotalPayble.Name = "labelTotalPayble";
            this.labelTotalPayble.Size = new System.Drawing.Size(0, 24);
            this.labelTotalPayble.TabIndex = 18;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(28, 207);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(165, 25);
            this.label17.TabIndex = 10;
            this.label17.Text = "Total Payble : ";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.buttonAdjustDue);
            this.groupBox1.Controls.Add(this.textBoxAdjustDue);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(460, 29);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(381, 98);
            this.groupBox1.TabIndex = 12;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Payment";
            // 
            // buttonAdjustDue
            // 
            this.buttonAdjustDue.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonAdjustDue.Location = new System.Drawing.Point(259, 38);
            this.buttonAdjustDue.Name = "buttonAdjustDue";
            this.buttonAdjustDue.Size = new System.Drawing.Size(112, 36);
            this.buttonAdjustDue.TabIndex = 4;
            this.buttonAdjustDue.Text = "Adjust Due";
            this.buttonAdjustDue.UseVisualStyleBackColor = true;
            this.buttonAdjustDue.Click += new System.EventHandler(this.buttonAdjustDue_Click);
            // 
            // textBoxAdjustDue
            // 
            this.textBoxAdjustDue.Location = new System.Drawing.Point(135, 43);
            this.textBoxAdjustDue.Name = "textBoxAdjustDue";
            this.textBoxAdjustDue.Size = new System.Drawing.Size(116, 24);
            this.textBoxAdjustDue.TabIndex = 3;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(6, 47);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(123, 18);
            this.label7.TabIndex = 1;
            this.label7.Text = "Due Payment : ";
            // 
            // buttonRefresh
            // 
            this.buttonRefresh.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonRefresh.Location = new System.Drawing.Point(349, 62);
            this.buttonRefresh.Name = "buttonRefresh";
            this.buttonRefresh.Size = new System.Drawing.Size(75, 23);
            this.buttonRefresh.TabIndex = 13;
            this.buttonRefresh.Text = "Refresh";
            this.buttonRefresh.UseVisualStyleBackColor = true;
            this.buttonRefresh.Click += new System.EventHandler(this.buttonRefresh_Click);
            // 
            // buttonDone
            // 
            this.buttonDone.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonDone.Location = new System.Drawing.Point(349, 95);
            this.buttonDone.Name = "buttonDone";
            this.buttonDone.Size = new System.Drawing.Size(75, 23);
            this.buttonDone.TabIndex = 14;
            this.buttonDone.Text = "Done";
            this.buttonDone.UseVisualStyleBackColor = true;
            this.buttonDone.Click += new System.EventHandler(this.buttonDone_Click);
            // 
            // comboBoxFlat
            // 
            this.comboBoxFlat.FormattingEnabled = true;
            this.comboBoxFlat.Location = new System.Drawing.Point(99, 64);
            this.comboBoxFlat.Name = "comboBoxFlat";
            this.comboBoxFlat.Size = new System.Drawing.Size(244, 21);
            this.comboBoxFlat.TabIndex = 5;
            // 
            // textBoxName
            // 
            this.textBoxName.Location = new System.Drawing.Point(99, 97);
            this.textBoxName.Name = "textBoxName";
            this.textBoxName.Size = new System.Drawing.Size(244, 20);
            this.textBoxName.TabIndex = 15;
            this.textBoxName.Click += new System.EventHandler(this.textBoxName_Click);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(206, 33);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(52, 18);
            this.label21.TabIndex = 32;
            this.label21.Text = "Year :";
            // 
            // textBoxYear
            // 
            this.textBoxYear.Location = new System.Drawing.Point(261, 34);
            this.textBoxYear.Name = "textBoxYear";
            this.textBoxYear.Size = new System.Drawing.Size(82, 20);
            this.textBoxYear.TabIndex = 31;
            // 
            // comboBoxDate
            // 
            this.comboBoxDate.FormattingEnabled = true;
            this.comboBoxDate.Items.AddRange(new object[] {
            "January",
            "February",
            "March",
            "April",
            "May",
            "June",
            "July",
            "August",
            "September",
            "October",
            "November",
            "December"});
            this.comboBoxDate.Location = new System.Drawing.Point(99, 31);
            this.comboBoxDate.Name = "comboBoxDate";
            this.comboBoxDate.Size = new System.Drawing.Size(101, 21);
            this.comboBoxDate.TabIndex = 29;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(23, 34);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(70, 18);
            this.label3.TabIndex = 30;
            this.label3.Text = "Month : ";
            // 
            // PreviewBillUI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(861, 437);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.textBoxYear);
            this.Controls.Add(this.comboBoxDate);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.textBoxName);
            this.Controls.Add(this.buttonDone);
            this.Controls.Add(this.buttonRefresh);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.groupBoxPreviewBill);
            this.Controls.Add(this.comboBoxFlat);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "PreviewBillUI";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "PreviewBill";
            this.groupBoxPreviewBill.ResumeLayout(false);
            this.groupBoxPreviewBill.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBoxPreviewBill;
        private System.Windows.Forms.Button buttonPrintBill;
        private System.Windows.Forms.Button buttonClose;
        private System.Windows.Forms.Label labelTotalPayble;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button buttonAdjustDue;
        private System.Windows.Forms.TextBox textBoxAdjustDue;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button buttonRefresh;
        private System.Windows.Forms.Button buttonDone;
        private System.Windows.Forms.Label labelDate;
        private System.Windows.Forms.Label labelMeterNo;
        private System.Windows.Forms.Label labelMonth;
        private System.Windows.Forms.Label labelName;
        private System.Windows.Forms.Label labelFlat;
        private System.Windows.Forms.Label labelVat;
        private System.Windows.Forms.Label labelDemandCharge;
        private System.Windows.Forms.Label labelServiceCharge;
        private System.Windows.Forms.Label labelUnitBill;
        private System.Windows.Forms.Label labelTotalUnit;
        private System.Windows.Forms.Label labelPreviousUnit;
        private System.Windows.Forms.Label labelPresentUnit;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label labelDue;
        private System.Windows.Forms.Label labelPay;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox comboBoxFlat;
        private System.Windows.Forms.TextBox textBoxName;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox textBoxYear;
        private System.Windows.Forms.ComboBox comboBoxDate;
        private System.Windows.Forms.Label label3;
    }
}