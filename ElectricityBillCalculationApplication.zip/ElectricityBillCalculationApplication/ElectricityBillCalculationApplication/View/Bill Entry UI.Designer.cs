﻿namespace ElectricityBillCalculationApplication
{
    partial class BillEntry
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBoxUnitEntry = new System.Windows.Forms.GroupBox();
            this.textBoxName = new System.Windows.Forms.TextBox();
            this.buttonEntryUnitAdd = new System.Windows.Forms.Button();
            this.comboBoxFlat = new System.Windows.Forms.ComboBox();
            this.buttonEntryUnitRefresh = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.textBoxTotalUnit = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.textBoxPreviousUnit = new System.Windows.Forms.TextBox();
            this.textBoxPresentUnit = new System.Windows.Forms.TextBox();
            this.dateTimePickerRecent = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.dateTimePickerPrevious = new System.Windows.Forms.DateTimePicker();
            this.label25 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.groupBoxPreviewBill = new System.Windows.Forms.GroupBox();
            this.labelDate = new System.Windows.Forms.Label();
            this.labelMeterNo = new System.Windows.Forms.Label();
            this.labelMonth = new System.Windows.Forms.Label();
            this.labelName = new System.Windows.Forms.Label();
            this.labelFlat = new System.Windows.Forms.Label();
            this.labelTotalPayble = new System.Windows.Forms.Label();
            this.labelVat = new System.Windows.Forms.Label();
            this.labelDemandCharge = new System.Windows.Forms.Label();
            this.labelServiceCharge = new System.Windows.Forms.Label();
            this.labelUnitBill = new System.Windows.Forms.Label();
            this.labelTotalUnit = new System.Windows.Forms.Label();
            this.labelPreviousUnit = new System.Windows.Forms.Label();
            this.labelPresentUnit = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.buttonPreviewBill = new System.Windows.Forms.Button();
            this.buttonUpdateTanentInfo = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.labelVatPercentage = new System.Windows.Forms.Label();
            this.labelUnitCostTill75 = new System.Windows.Forms.Label();
            this.labelUnitCostMoreThan600 = new System.Windows.Forms.Label();
            this.labelUnitCostTill600 = new System.Windows.Forms.Label();
            this.labelUnitCostTill400 = new System.Windows.Forms.Label();
            this.labelUnitCostTill300 = new System.Windows.Forms.Label();
            this.labelUnitCostTill200 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.buttonDuePayment = new System.Windows.Forms.Button();
            this.buttonPrintBill = new System.Windows.Forms.Button();
            this.buttonExit = new System.Windows.Forms.Button();
            this.buttonAddTanentInfo = new System.Windows.Forms.Button();
            this.buttonPaymentBill = new System.Windows.Forms.Button();
            this.buttonUpdateUnitPrice = new System.Windows.Forms.Button();
            this.buttonUpdateVatAndCharge = new System.Windows.Forms.Button();
            this.buttonSetUnitPrice = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.buttonSearch = new System.Windows.Forms.Button();
            this.groupBoxUnitEntry.SuspendLayout();
            this.groupBoxPreviewBill.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBoxUnitEntry
            // 
            this.groupBoxUnitEntry.Controls.Add(this.textBoxName);
            this.groupBoxUnitEntry.Controls.Add(this.buttonEntryUnitAdd);
            this.groupBoxUnitEntry.Controls.Add(this.comboBoxFlat);
            this.groupBoxUnitEntry.Controls.Add(this.buttonEntryUnitRefresh);
            this.groupBoxUnitEntry.Controls.Add(this.label6);
            this.groupBoxUnitEntry.Controls.Add(this.textBoxTotalUnit);
            this.groupBoxUnitEntry.Controls.Add(this.label5);
            this.groupBoxUnitEntry.Controls.Add(this.textBoxPreviousUnit);
            this.groupBoxUnitEntry.Controls.Add(this.textBoxPresentUnit);
            this.groupBoxUnitEntry.Controls.Add(this.dateTimePickerRecent);
            this.groupBoxUnitEntry.Controls.Add(this.label1);
            this.groupBoxUnitEntry.Controls.Add(this.dateTimePickerPrevious);
            this.groupBoxUnitEntry.Controls.Add(this.label25);
            this.groupBoxUnitEntry.Controls.Add(this.label24);
            this.groupBoxUnitEntry.Controls.Add(this.label23);
            this.groupBoxUnitEntry.Controls.Add(this.label30);
            this.groupBoxUnitEntry.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBoxUnitEntry.Location = new System.Drawing.Point(12, 12);
            this.groupBoxUnitEntry.Name = "groupBoxUnitEntry";
            this.groupBoxUnitEntry.Size = new System.Drawing.Size(582, 190);
            this.groupBoxUnitEntry.TabIndex = 0;
            this.groupBoxUnitEntry.TabStop = false;
            this.groupBoxUnitEntry.Text = "Enter Unit";
            // 
            // textBoxName
            // 
            this.textBoxName.Location = new System.Drawing.Point(333, 103);
            this.textBoxName.Name = "textBoxName";
            this.textBoxName.Size = new System.Drawing.Size(198, 24);
            this.textBoxName.TabIndex = 18;
            this.textBoxName.Click += new System.EventHandler(this.textBoxName_Click);
            // 
            // buttonEntryUnitAdd
            // 
            this.buttonEntryUnitAdd.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.buttonEntryUnitAdd.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonEntryUnitAdd.Location = new System.Drawing.Point(439, 144);
            this.buttonEntryUnitAdd.Name = "buttonEntryUnitAdd";
            this.buttonEntryUnitAdd.Size = new System.Drawing.Size(92, 25);
            this.buttonEntryUnitAdd.TabIndex = 17;
            this.buttonEntryUnitAdd.Text = "ADD";
            this.buttonEntryUnitAdd.UseVisualStyleBackColor = false;
            this.buttonEntryUnitAdd.Click += new System.EventHandler(this.buttonEntryUnitAdd_Click);
            // 
            // comboBoxFlat
            // 
            this.comboBoxFlat.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.comboBoxFlat.FormattingEnabled = true;
            this.comboBoxFlat.Location = new System.Drawing.Point(333, 69);
            this.comboBoxFlat.Name = "comboBoxFlat";
            this.comboBoxFlat.Size = new System.Drawing.Size(197, 26);
            this.comboBoxFlat.TabIndex = 2;
            this.comboBoxFlat.SelectedIndexChanged += new System.EventHandler(this.comboBoxFlat_SelectedIndexChanged);
            this.comboBoxFlat.MouseClick += new System.Windows.Forms.MouseEventHandler(this.comboBoxFlat_MouseClick);
            // 
            // buttonEntryUnitRefresh
            // 
            this.buttonEntryUnitRefresh.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.buttonEntryUnitRefresh.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonEntryUnitRefresh.Location = new System.Drawing.Point(333, 144);
            this.buttonEntryUnitRefresh.Name = "buttonEntryUnitRefresh";
            this.buttonEntryUnitRefresh.Size = new System.Drawing.Size(100, 25);
            this.buttonEntryUnitRefresh.TabIndex = 16;
            this.buttonEntryUnitRefresh.Text = "Refresh";
            this.buttonEntryUnitRefresh.UseVisualStyleBackColor = false;
            this.buttonEntryUnitRefresh.Click += new System.EventHandler(this.buttonEntryUnitRefresh_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(279, 75);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(44, 18);
            this.label6.TabIndex = 1;
            this.label6.Text = "Flat : ";
            // 
            // textBoxTotalUnit
            // 
            this.textBoxTotalUnit.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxTotalUnit.Location = new System.Drawing.Point(130, 141);
            this.textBoxTotalUnit.Name = "textBoxTotalUnit";
            this.textBoxTotalUnit.Size = new System.Drawing.Size(131, 24);
            this.textBoxTotalUnit.TabIndex = 9;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(279, 107);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(60, 18);
            this.label5.TabIndex = 1;
            this.label5.Text = "Name : ";
            // 
            // textBoxPreviousUnit
            // 
            this.textBoxPreviousUnit.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxPreviousUnit.Location = new System.Drawing.Point(130, 105);
            this.textBoxPreviousUnit.Name = "textBoxPreviousUnit";
            this.textBoxPreviousUnit.Size = new System.Drawing.Size(131, 24);
            this.textBoxPreviousUnit.TabIndex = 4;
            // 
            // textBoxPresentUnit
            // 
            this.textBoxPresentUnit.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxPresentUnit.Location = new System.Drawing.Point(130, 65);
            this.textBoxPresentUnit.Name = "textBoxPresentUnit";
            this.textBoxPresentUnit.Size = new System.Drawing.Size(131, 24);
            this.textBoxPresentUnit.TabIndex = 3;
            // 
            // dateTimePickerRecent
            // 
            this.dateTimePickerRecent.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePickerRecent.Location = new System.Drawing.Point(333, 31);
            this.dateTimePickerRecent.Name = "dateTimePickerRecent";
            this.dateTimePickerRecent.Size = new System.Drawing.Size(197, 20);
            this.dateTimePickerRecent.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(298, 31);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(29, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "To";
            // 
            // dateTimePickerPrevious
            // 
            this.dateTimePickerPrevious.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePickerPrevious.Location = new System.Drawing.Point(80, 30);
            this.dateTimePickerPrevious.Name = "dateTimePickerPrevious";
            this.dateTimePickerPrevious.Size = new System.Drawing.Size(198, 20);
            this.dateTimePickerPrevious.TabIndex = 1;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(23, 144);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(83, 18);
            this.label25.TabIndex = 1;
            this.label25.Text = "Total Unit : ";
            this.label25.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(23, 108);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(108, 18);
            this.label24.TabIndex = 0;
            this.label24.Text = "Previous Unit : ";
            this.label24.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(23, 68);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(101, 18);
            this.label23.TabIndex = 0;
            this.label23.Text = "Present Unit : ";
            this.label23.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(23, 29);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(48, 18);
            this.label30.TabIndex = 0;
            this.label30.Text = "From";
            this.label30.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // groupBoxPreviewBill
            // 
            this.groupBoxPreviewBill.Controls.Add(this.labelDate);
            this.groupBoxPreviewBill.Controls.Add(this.labelMeterNo);
            this.groupBoxPreviewBill.Controls.Add(this.labelMonth);
            this.groupBoxPreviewBill.Controls.Add(this.labelName);
            this.groupBoxPreviewBill.Controls.Add(this.labelFlat);
            this.groupBoxPreviewBill.Controls.Add(this.labelTotalPayble);
            this.groupBoxPreviewBill.Controls.Add(this.labelVat);
            this.groupBoxPreviewBill.Controls.Add(this.labelDemandCharge);
            this.groupBoxPreviewBill.Controls.Add(this.labelServiceCharge);
            this.groupBoxPreviewBill.Controls.Add(this.labelUnitBill);
            this.groupBoxPreviewBill.Controls.Add(this.labelTotalUnit);
            this.groupBoxPreviewBill.Controls.Add(this.labelPreviousUnit);
            this.groupBoxPreviewBill.Controls.Add(this.labelPresentUnit);
            this.groupBoxPreviewBill.Controls.Add(this.label17);
            this.groupBoxPreviewBill.Controls.Add(this.label16);
            this.groupBoxPreviewBill.Controls.Add(this.label15);
            this.groupBoxPreviewBill.Controls.Add(this.label14);
            this.groupBoxPreviewBill.Controls.Add(this.label13);
            this.groupBoxPreviewBill.Controls.Add(this.label12);
            this.groupBoxPreviewBill.Controls.Add(this.label11);
            this.groupBoxPreviewBill.Controls.Add(this.label10);
            this.groupBoxPreviewBill.Controls.Add(this.label9);
            this.groupBoxPreviewBill.Controls.Add(this.label8);
            this.groupBoxPreviewBill.Controls.Add(this.label2);
            this.groupBoxPreviewBill.Controls.Add(this.label7);
            this.groupBoxPreviewBill.Controls.Add(this.label4);
            this.groupBoxPreviewBill.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBoxPreviewBill.Location = new System.Drawing.Point(12, 208);
            this.groupBoxPreviewBill.Name = "groupBoxPreviewBill";
            this.groupBoxPreviewBill.Size = new System.Drawing.Size(802, 288);
            this.groupBoxPreviewBill.TabIndex = 10;
            this.groupBoxPreviewBill.TabStop = false;
            this.groupBoxPreviewBill.Text = "Total  Payble Bill";
            // 
            // labelDate
            // 
            this.labelDate.AutoSize = true;
            this.labelDate.Location = new System.Drawing.Point(148, 32);
            this.labelDate.Name = "labelDate";
            this.labelDate.Size = new System.Drawing.Size(0, 18);
            this.labelDate.TabIndex = 21;
            // 
            // labelMeterNo
            // 
            this.labelMeterNo.AutoSize = true;
            this.labelMeterNo.Location = new System.Drawing.Point(148, 79);
            this.labelMeterNo.Name = "labelMeterNo";
            this.labelMeterNo.Size = new System.Drawing.Size(0, 18);
            this.labelMeterNo.TabIndex = 21;
            // 
            // labelMonth
            // 
            this.labelMonth.AutoSize = true;
            this.labelMonth.Location = new System.Drawing.Point(147, 58);
            this.labelMonth.Name = "labelMonth";
            this.labelMonth.Size = new System.Drawing.Size(0, 18);
            this.labelMonth.TabIndex = 21;
            // 
            // labelName
            // 
            this.labelName.AutoSize = true;
            this.labelName.Location = new System.Drawing.Point(147, 101);
            this.labelName.Name = "labelName";
            this.labelName.Size = new System.Drawing.Size(0, 18);
            this.labelName.TabIndex = 20;
            // 
            // labelFlat
            // 
            this.labelFlat.AutoSize = true;
            this.labelFlat.Location = new System.Drawing.Point(149, 125);
            this.labelFlat.Name = "labelFlat";
            this.labelFlat.Size = new System.Drawing.Size(0, 18);
            this.labelFlat.TabIndex = 19;
            // 
            // labelTotalPayble
            // 
            this.labelTotalPayble.AutoSize = true;
            this.labelTotalPayble.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTotalPayble.Location = new System.Drawing.Point(618, 207);
            this.labelTotalPayble.Name = "labelTotalPayble";
            this.labelTotalPayble.Size = new System.Drawing.Size(0, 24);
            this.labelTotalPayble.TabIndex = 18;
            // 
            // labelVat
            // 
            this.labelVat.AutoSize = true;
            this.labelVat.Location = new System.Drawing.Point(601, 171);
            this.labelVat.Name = "labelVat";
            this.labelVat.Size = new System.Drawing.Size(0, 18);
            this.labelVat.TabIndex = 17;
            // 
            // labelDemandCharge
            // 
            this.labelDemandCharge.AutoSize = true;
            this.labelDemandCharge.Location = new System.Drawing.Point(600, 148);
            this.labelDemandCharge.Name = "labelDemandCharge";
            this.labelDemandCharge.Size = new System.Drawing.Size(0, 18);
            this.labelDemandCharge.TabIndex = 16;
            // 
            // labelServiceCharge
            // 
            this.labelServiceCharge.AutoSize = true;
            this.labelServiceCharge.Location = new System.Drawing.Point(599, 123);
            this.labelServiceCharge.Name = "labelServiceCharge";
            this.labelServiceCharge.Size = new System.Drawing.Size(0, 18);
            this.labelServiceCharge.TabIndex = 15;
            // 
            // labelUnitBill
            // 
            this.labelUnitBill.AutoSize = true;
            this.labelUnitBill.Location = new System.Drawing.Point(599, 102);
            this.labelUnitBill.Name = "labelUnitBill";
            this.labelUnitBill.Size = new System.Drawing.Size(0, 18);
            this.labelUnitBill.TabIndex = 14;
            // 
            // labelTotalUnit
            // 
            this.labelTotalUnit.AutoSize = true;
            this.labelTotalUnit.Location = new System.Drawing.Point(599, 78);
            this.labelTotalUnit.Name = "labelTotalUnit";
            this.labelTotalUnit.Size = new System.Drawing.Size(0, 18);
            this.labelTotalUnit.TabIndex = 13;
            // 
            // labelPreviousUnit
            // 
            this.labelPreviousUnit.AutoSize = true;
            this.labelPreviousUnit.Location = new System.Drawing.Point(149, 172);
            this.labelPreviousUnit.Name = "labelPreviousUnit";
            this.labelPreviousUnit.Size = new System.Drawing.Size(0, 18);
            this.labelPreviousUnit.TabIndex = 12;
            // 
            // labelPresentUnit
            // 
            this.labelPresentUnit.AutoSize = true;
            this.labelPresentUnit.Location = new System.Drawing.Point(149, 147);
            this.labelPresentUnit.Name = "labelPresentUnit";
            this.labelPresentUnit.Size = new System.Drawing.Size(0, 18);
            this.labelPresentUnit.TabIndex = 11;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(469, 207);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(165, 25);
            this.label17.TabIndex = 10;
            this.label17.Text = "Total Payble : ";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(473, 174);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(53, 18);
            this.label16.TabIndex = 9;
            this.label16.Text = "VAT : ";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(474, 102);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(81, 18);
            this.label15.TabIndex = 8;
            this.label15.Text = "Unit Bill : ";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(474, 147);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(144, 18);
            this.label14.TabIndex = 7;
            this.label14.Text = "Demand Charge : ";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(473, 123);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(138, 18);
            this.label13.TabIndex = 6;
            this.label13.Text = "Service Charge : ";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(474, 76);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(96, 18);
            this.label12.TabIndex = 5;
            this.label12.Text = "Total Unit : ";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(23, 172);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(119, 18);
            this.label11.TabIndex = 4;
            this.label11.Text = "Previous Unit: ";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(23, 147);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(116, 18);
            this.label10.TabIndex = 3;
            this.label10.Text = "Present Unit : ";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(23, 124);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(51, 18);
            this.label9.TabIndex = 2;
            this.label9.Text = "Flat : ";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(23, 101);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(67, 18);
            this.label8.TabIndex = 1;
            this.label8.Text = "Name : ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(24, 32);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(58, 18);
            this.label2.TabIndex = 0;
            this.label2.Text = "Date : ";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(24, 79);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(93, 18);
            this.label7.TabIndex = 0;
            this.label7.Text = "Meter No : ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(23, 58);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(70, 18);
            this.label4.TabIndex = 0;
            this.label4.Text = "Month : ";
            // 
            // buttonPreviewBill
            // 
            this.buttonPreviewBill.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.buttonPreviewBill.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonPreviewBill.Location = new System.Drawing.Point(840, 61);
            this.buttonPreviewBill.Name = "buttonPreviewBill";
            this.buttonPreviewBill.Size = new System.Drawing.Size(215, 35);
            this.buttonPreviewBill.TabIndex = 4;
            this.buttonPreviewBill.Text = "Preview Bill";
            this.buttonPreviewBill.UseVisualStyleBackColor = false;
            this.buttonPreviewBill.Click += new System.EventHandler(this.buttonPreviewBill_Click);
            // 
            // buttonUpdateTanentInfo
            // 
            this.buttonUpdateTanentInfo.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.buttonUpdateTanentInfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonUpdateTanentInfo.Location = new System.Drawing.Point(840, 222);
            this.buttonUpdateTanentInfo.Name = "buttonUpdateTanentInfo";
            this.buttonUpdateTanentInfo.Size = new System.Drawing.Size(215, 33);
            this.buttonUpdateTanentInfo.TabIndex = 6;
            this.buttonUpdateTanentInfo.Text = "Update Tenant Info";
            this.buttonUpdateTanentInfo.UseVisualStyleBackColor = false;
            this.buttonUpdateTanentInfo.Click += new System.EventHandler(this.buttonUpdateTanentInfo_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.labelVatPercentage);
            this.groupBox1.Controls.Add(this.labelUnitCostTill75);
            this.groupBox1.Controls.Add(this.labelUnitCostMoreThan600);
            this.groupBox1.Controls.Add(this.labelUnitCostTill600);
            this.groupBox1.Controls.Add(this.labelUnitCostTill400);
            this.groupBox1.Controls.Add(this.labelUnitCostTill300);
            this.groupBox1.Controls.Add(this.labelUnitCostTill200);
            this.groupBox1.Controls.Add(this.label21);
            this.groupBox1.Controls.Add(this.label22);
            this.groupBox1.Controls.Add(this.label20);
            this.groupBox1.Controls.Add(this.label26);
            this.groupBox1.Controls.Add(this.label19);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label18);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(600, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(214, 190);
            this.groupBox1.TabIndex = 9;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Condition";
            // 
            // labelVatPercentage
            // 
            this.labelVatPercentage.AutoSize = true;
            this.labelVatPercentage.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelVatPercentage.Location = new System.Drawing.Point(74, 152);
            this.labelVatPercentage.Name = "labelVatPercentage";
            this.labelVatPercentage.Size = new System.Drawing.Size(0, 16);
            this.labelVatPercentage.TabIndex = 5;
            // 
            // labelUnitCostTill75
            // 
            this.labelUnitCostTill75.AutoSize = true;
            this.labelUnitCostTill75.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelUnitCostTill75.Location = new System.Drawing.Point(147, 33);
            this.labelUnitCostTill75.Name = "labelUnitCostTill75";
            this.labelUnitCostTill75.Size = new System.Drawing.Size(0, 16);
            this.labelUnitCostTill75.TabIndex = 4;
            // 
            // labelUnitCostMoreThan600
            // 
            this.labelUnitCostMoreThan600.AutoSize = true;
            this.labelUnitCostMoreThan600.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelUnitCostMoreThan600.Location = new System.Drawing.Point(182, 132);
            this.labelUnitCostMoreThan600.Name = "labelUnitCostMoreThan600";
            this.labelUnitCostMoreThan600.Size = new System.Drawing.Size(0, 16);
            this.labelUnitCostMoreThan600.TabIndex = 4;
            // 
            // labelUnitCostTill600
            // 
            this.labelUnitCostTill600.AutoSize = true;
            this.labelUnitCostTill600.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelUnitCostTill600.Location = new System.Drawing.Point(147, 111);
            this.labelUnitCostTill600.Name = "labelUnitCostTill600";
            this.labelUnitCostTill600.Size = new System.Drawing.Size(0, 16);
            this.labelUnitCostTill600.TabIndex = 4;
            // 
            // labelUnitCostTill400
            // 
            this.labelUnitCostTill400.AutoSize = true;
            this.labelUnitCostTill400.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelUnitCostTill400.Location = new System.Drawing.Point(147, 92);
            this.labelUnitCostTill400.Name = "labelUnitCostTill400";
            this.labelUnitCostTill400.Size = new System.Drawing.Size(0, 16);
            this.labelUnitCostTill400.TabIndex = 4;
            // 
            // labelUnitCostTill300
            // 
            this.labelUnitCostTill300.AutoSize = true;
            this.labelUnitCostTill300.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelUnitCostTill300.Location = new System.Drawing.Point(147, 73);
            this.labelUnitCostTill300.Name = "labelUnitCostTill300";
            this.labelUnitCostTill300.Size = new System.Drawing.Size(0, 16);
            this.labelUnitCostTill300.TabIndex = 4;
            // 
            // labelUnitCostTill200
            // 
            this.labelUnitCostTill200.AutoSize = true;
            this.labelUnitCostTill200.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelUnitCostTill200.Location = new System.Drawing.Point(147, 52);
            this.labelUnitCostTill200.Name = "labelUnitCostTill200";
            this.labelUnitCostTill200.Size = new System.Drawing.Size(0, 16);
            this.labelUnitCostTill200.TabIndex = 4;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(18, 151);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(41, 16);
            this.label21.TabIndex = 3;
            this.label21.Text = "VAT :";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(18, 130);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(166, 16);
            this.label22.TabIndex = 2;
            this.label22.Text = "More Than 600 Unit Price : ";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(18, 111);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(129, 16);
            this.label20.TabIndex = 2;
            this.label20.Text = "401 - 600 Unit Price : ";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(18, 73);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(129, 16);
            this.label26.TabIndex = 1;
            this.label26.Text = "201 - 300 Unit Price : ";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(18, 92);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(129, 16);
            this.label19.TabIndex = 1;
            this.label19.Text = "301 - 400 Unit Price : ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(18, 33);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(108, 16);
            this.label3.TabIndex = 0;
            this.label3.Text = "0 - 75 Unit Price : ";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(18, 52);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(122, 16);
            this.label18.TabIndex = 0;
            this.label18.Text = "76 - 200 Unit Price : ";
            // 
            // buttonDuePayment
            // 
            this.buttonDuePayment.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.buttonDuePayment.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonDuePayment.Location = new System.Drawing.Point(840, 144);
            this.buttonDuePayment.Name = "buttonDuePayment";
            this.buttonDuePayment.Size = new System.Drawing.Size(215, 33);
            this.buttonDuePayment.TabIndex = 6;
            this.buttonDuePayment.Text = "Due Payment";
            this.buttonDuePayment.UseVisualStyleBackColor = false;
            this.buttonDuePayment.Click += new System.EventHandler(this.buttonDuePayment_Click);
            // 
            // buttonPrintBill
            // 
            this.buttonPrintBill.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.buttonPrintBill.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonPrintBill.Location = new System.Drawing.Point(840, 417);
            this.buttonPrintBill.Name = "buttonPrintBill";
            this.buttonPrintBill.Size = new System.Drawing.Size(215, 39);
            this.buttonPrintBill.TabIndex = 6;
            this.buttonPrintBill.Text = "Print Bill";
            this.buttonPrintBill.UseVisualStyleBackColor = false;
            this.buttonPrintBill.Click += new System.EventHandler(this.buttonPrintBill_Click);
            // 
            // buttonExit
            // 
            this.buttonExit.BackColor = System.Drawing.Color.IndianRed;
            this.buttonExit.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonExit.Location = new System.Drawing.Point(840, 462);
            this.buttonExit.Name = "buttonExit";
            this.buttonExit.Size = new System.Drawing.Size(215, 34);
            this.buttonExit.TabIndex = 6;
            this.buttonExit.Text = "Exit";
            this.buttonExit.UseVisualStyleBackColor = false;
            this.buttonExit.Click += new System.EventHandler(this.buttonExit_Click);
            // 
            // buttonAddTanentInfo
            // 
            this.buttonAddTanentInfo.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.buttonAddTanentInfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonAddTanentInfo.Location = new System.Drawing.Point(840, 183);
            this.buttonAddTanentInfo.Name = "buttonAddTanentInfo";
            this.buttonAddTanentInfo.Size = new System.Drawing.Size(215, 33);
            this.buttonAddTanentInfo.TabIndex = 6;
            this.buttonAddTanentInfo.Text = "Add Tenant Info";
            this.buttonAddTanentInfo.UseVisualStyleBackColor = false;
            this.buttonAddTanentInfo.Click += new System.EventHandler(this.buttonAddTanentInfo_Click);
            // 
            // buttonPaymentBill
            // 
            this.buttonPaymentBill.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.buttonPaymentBill.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonPaymentBill.Location = new System.Drawing.Point(840, 102);
            this.buttonPaymentBill.Name = "buttonPaymentBill";
            this.buttonPaymentBill.Size = new System.Drawing.Size(215, 36);
            this.buttonPaymentBill.TabIndex = 11;
            this.buttonPaymentBill.Text = "Bill Payment";
            this.buttonPaymentBill.UseVisualStyleBackColor = false;
            this.buttonPaymentBill.Click += new System.EventHandler(this.buttonPaymentBill_Click);
            // 
            // buttonUpdateUnitPrice
            // 
            this.buttonUpdateUnitPrice.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.buttonUpdateUnitPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonUpdateUnitPrice.Location = new System.Drawing.Point(840, 300);
            this.buttonUpdateUnitPrice.Name = "buttonUpdateUnitPrice";
            this.buttonUpdateUnitPrice.Size = new System.Drawing.Size(215, 33);
            this.buttonUpdateUnitPrice.TabIndex = 12;
            this.buttonUpdateUnitPrice.Text = "Update Unit Price";
            this.buttonUpdateUnitPrice.UseVisualStyleBackColor = false;
            this.buttonUpdateUnitPrice.Click += new System.EventHandler(this.buttonUpdateUnitPrice_Click);
            // 
            // buttonUpdateVatAndCharge
            // 
            this.buttonUpdateVatAndCharge.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.buttonUpdateVatAndCharge.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonUpdateVatAndCharge.Location = new System.Drawing.Point(840, 378);
            this.buttonUpdateVatAndCharge.Name = "buttonUpdateVatAndCharge";
            this.buttonUpdateVatAndCharge.Size = new System.Drawing.Size(215, 33);
            this.buttonUpdateVatAndCharge.TabIndex = 13;
            this.buttonUpdateVatAndCharge.Text = "Update Vat&Charge";
            this.buttonUpdateVatAndCharge.UseVisualStyleBackColor = false;
            this.buttonUpdateVatAndCharge.Click += new System.EventHandler(this.buttonUpdateVatAndCharge_Click);
            // 
            // buttonSetUnitPrice
            // 
            this.buttonSetUnitPrice.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.buttonSetUnitPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonSetUnitPrice.Location = new System.Drawing.Point(840, 261);
            this.buttonSetUnitPrice.Name = "buttonSetUnitPrice";
            this.buttonSetUnitPrice.Size = new System.Drawing.Size(215, 33);
            this.buttonSetUnitPrice.TabIndex = 12;
            this.buttonSetUnitPrice.Text = "Set Unit Price";
            this.buttonSetUnitPrice.UseVisualStyleBackColor = false;
            this.buttonSetUnitPrice.Click += new System.EventHandler(this.buttonSetUnitPrice_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(840, 339);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(215, 33);
            this.button2.TabIndex = 12;
            this.button2.Text = "Set Vat & Charge";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // buttonSearch
            // 
            this.buttonSearch.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.buttonSearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonSearch.Location = new System.Drawing.Point(840, 21);
            this.buttonSearch.Name = "buttonSearch";
            this.buttonSearch.Size = new System.Drawing.Size(215, 34);
            this.buttonSearch.TabIndex = 14;
            this.buttonSearch.Text = "Search";
            this.buttonSearch.UseVisualStyleBackColor = false;
            this.buttonSearch.Click += new System.EventHandler(this.buttonSearch_Click);
            // 
            // BillEntry
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1067, 508);
            this.Controls.Add(this.buttonSearch);
            this.Controls.Add(this.buttonUpdateVatAndCharge);
            this.Controls.Add(this.buttonSetUnitPrice);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.buttonUpdateUnitPrice);
            this.Controls.Add(this.buttonPaymentBill);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.buttonExit);
            this.Controls.Add(this.buttonPrintBill);
            this.Controls.Add(this.buttonDuePayment);
            this.Controls.Add(this.buttonAddTanentInfo);
            this.Controls.Add(this.buttonUpdateTanentInfo);
            this.Controls.Add(this.buttonPreviewBill);
            this.Controls.Add(this.groupBoxPreviewBill);
            this.Controls.Add(this.groupBoxUnitEntry);
            this.Name = "BillEntry";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Electricity Bill Entry From";
            this.groupBoxUnitEntry.ResumeLayout(false);
            this.groupBoxUnitEntry.PerformLayout();
            this.groupBoxPreviewBill.ResumeLayout(false);
            this.groupBoxPreviewBill.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBoxUnitEntry;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.GroupBox groupBoxPreviewBill;
        private System.Windows.Forms.Button buttonPreviewBill;
        private System.Windows.Forms.Button buttonUpdateTanentInfo;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox textBoxTotalUnit;
        private System.Windows.Forms.TextBox textBoxPreviousUnit;
        private System.Windows.Forms.TextBox textBoxPresentUnit;
        private System.Windows.Forms.DateTimePicker dateTimePickerRecent;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DateTimePicker dateTimePickerPrevious;
        private System.Windows.Forms.Button buttonEntryUnitAdd;
        private System.Windows.Forms.Button buttonEntryUnitRefresh;
        private System.Windows.Forms.ComboBox comboBoxFlat;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Button buttonDuePayment;
        private System.Windows.Forms.Button buttonPrintBill;
        private System.Windows.Forms.Button buttonExit;
        private System.Windows.Forms.Button buttonAddTanentInfo;
        private System.Windows.Forms.Label labelPresentUnit;
        private System.Windows.Forms.Label labelMonth;
        private System.Windows.Forms.Label labelName;
        private System.Windows.Forms.Label labelFlat;
        private System.Windows.Forms.Label labelTotalPayble;
        private System.Windows.Forms.Label labelVat;
        private System.Windows.Forms.Label labelDemandCharge;
        private System.Windows.Forms.Label labelServiceCharge;
        private System.Windows.Forms.Label labelUnitBill;
        private System.Windows.Forms.Label labelTotalUnit;
        private System.Windows.Forms.Label labelPreviousUnit;
        private System.Windows.Forms.Button buttonPaymentBill;
        private System.Windows.Forms.Label labelDate;
        private System.Windows.Forms.Label labelMeterNo;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button buttonUpdateUnitPrice;
        private System.Windows.Forms.Button buttonUpdateVatAndCharge;
        private System.Windows.Forms.Button buttonSetUnitPrice;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label labelUnitCostTill75;
        private System.Windows.Forms.Label labelUnitCostMoreThan600;
        private System.Windows.Forms.Label labelUnitCostTill600;
        private System.Windows.Forms.Label labelUnitCostTill400;
        private System.Windows.Forms.Label labelUnitCostTill300;
        private System.Windows.Forms.Label labelUnitCostTill200;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label labelVatPercentage;
        private System.Windows.Forms.Button buttonSearch;
        private System.Windows.Forms.TextBox textBoxName;
    }
}

