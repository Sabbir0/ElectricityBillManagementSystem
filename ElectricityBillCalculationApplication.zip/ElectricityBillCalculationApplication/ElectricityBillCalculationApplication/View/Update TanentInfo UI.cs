﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ElectricityBillCalculationApplication.Model;

namespace ElectricityBillCalculationApplication.View
{
    public partial class UpdateTanentInfoUI : Form
    {
        public UpdateTanentInfoUI()
        {
            InitializeComponent();
            LoadTanentInfo();
        }
        TanentInfo aTanentInfo = new TanentInfo();

        private void LoadTanentInfo()
        {
           
            TanentInfo aTanentInfo = new TanentInfo();
            dataGridViewUpdateTanent.DataSource = aTanentInfo.Tanent().Tables[0];
        }

      public void ClearField()
      {
          textBoxName.Text = "";
          textBoxFlat.Text = "";
          textBoxMeterNo.Text = "";
        }

        private void buttonUpdateTanent_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBoxName.Text) && !string.IsNullOrEmpty(textBoxFlat.Text) && !string.IsNullOrEmpty(textBoxMeterNo.Text))
            {
                aTanentInfo.UpdateTanentInfo(textBoxName.Text,
                                        textBoxFlat.Text,
                                        textBoxMeterNo.Text);
                MessageBox.Show("Update Successfully!");
                ClearField();
                LoadTanentInfo();
            }
            else
            {
                MessageBox.Show("Empty Field !");
                
            }
           
        }

        private void buttonClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void dataGridViewUpdateTanent_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int SelectTanent = Convert.ToInt32(dataGridViewUpdateTanent.Rows[e.RowIndex].Cells[0].Value);

            DataSet aData = aTanentInfo.Tanent(SelectTanent);

            textBoxName.Text = aData.Tables[0].Rows[0]["TanentName"].ToString();
            textBoxFlat.Text = aData.Tables[0].Rows[0]["Flat"].ToString();
            textBoxMeterNo.Text = aData.Tables[0].Rows[0]["MeterNo"].ToString();
        }


    }
}
