﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ElectricityBillCalculationApplication.Model;

namespace ElectricityBillCalculationApplication.View
{
    public partial class DuePaymentUI : Form
    {
        public DuePaymentUI()
        {
            InitializeComponent();
            LoadDue();
        }
        DueBill aDueBill = new DueBill();
        private void LoadDue()
        {
            DueBill aDueBill = new DueBill();
            List<DueBill> dueBillList = new List<DueBill>();
            dueBillList = aDueBill.Due();
            dataGridViewDueBill.DataSource = dueBillList;       
        }
        private void ClearField()
        {
             textBoxMonth.Text = ""; 
             textBoxFlat.Text = "";
             textBoxName.Text = "";
             textBoxTotalPayble.Text = "";
             textBoxPay.Text = "";
             textBoxDue.Text = "";
             textBoxAdjustDue.Text = "";
        }

       private void dataGridViewDueBill_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int SelectBill = Convert.ToInt32(dataGridViewDueBill.Rows[e.RowIndex].Cells[0].Value);

            AdjustDue aAdjustDue = new AdjustDue();
            List<AdjustDue> adjustDueList = new List<AdjustDue>();
            adjustDueList = aAdjustDue.Due(SelectBill);

            foreach (var i in adjustDueList)
            {
                 textBoxMonth.Text = i.Month.ToString();
                 textBoxFlat.Text = i.Flat.ToString();
                 textBoxName.Text = i.TanentName.ToString();
                 textBoxTotalPayble.Text = i.TotalPayble.ToString();
                 textBoxPay.Text = i.Pay.ToString();
                 textBoxDue.Text = i.PreviousDue.ToString();
                
            }
        }

        private void buttonClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void buttonAdjustDue_Click(object sender, EventArgs e)
        {
            AdjustDue aAdjustDue = new AdjustDue();
            if (Convert.ToDouble(textBoxAdjustDue.Text) > Convert.ToDouble(textBoxDue.Text))
            {
                MessageBox.Show("Can not Greater Than Due!");
                textBoxAdjustDue.Text = "";
            }
            else
            {
                aAdjustDue.BillId = aAdjustDue.BillID(textBoxFlat.Text, textBoxMonth.Text);

                aAdjustDue.AdjustedDue = Convert.ToDouble(textBoxAdjustDue.Text);
                aAdjustDue.Pay = Convert.ToDouble(textBoxPay.Text);
                aAdjustDue.PreviousDue = Convert.ToDouble(textBoxDue.Text);

                aAdjustDue.UpdateDue();
                MessageBox.Show("Due Update Successfully!");
                ClearField();
                LoadDue();
            }
            
        }


    }
}
