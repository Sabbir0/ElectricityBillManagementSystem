﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ElectricityBillCalculationApplication.Model;

namespace ElectricityBillCalculationApplication.View
{
    public partial class SearchUI : Form
    {
        public SearchUI()
        {
            InitializeComponent();
            LoadBillDetails();
        }
        private void LoadBillDetails()
        {
            TanentInfo aTanentInfo = new TanentInfo();


            comboBoxFlat.DisplayMember = "Flat";
            comboBoxFlat.ValueMember = "TanentID";
            comboBoxFlat.DataSource = aTanentInfo.Tanent().Tables[0];

            MonthInfo aMonthInfo = new MonthInfo();

            comboBoxDate.SelectedIndex = -1;
            comboBoxFlat.SelectedIndex = -1;


        }

        private void buttonDone_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(comboBoxFlat.Text) && !string.IsNullOrEmpty(comboBoxDate.Text) && !string.IsNullOrEmpty(textBoxYear.Text))
            {
                MessageBox.Show("Please Only Flat / Month & Year.");
            }
            else if (!string.IsNullOrEmpty(comboBoxFlat.Text) && !string.IsNullOrEmpty(comboBoxDate.Text) && string.IsNullOrEmpty(textBoxYear.Text))
            {
                MessageBox.Show("Please Only Flat / Month & Year.");
            }
            else if (!string.IsNullOrEmpty(comboBoxFlat.Text) && string.IsNullOrEmpty(comboBoxDate.Text) && !string.IsNullOrEmpty(textBoxYear.Text))
            {
                MessageBox.Show("Please Only Flat / Month & Year.");
            }
            else if (!string.IsNullOrEmpty(comboBoxFlat.Text))
            {
                Search aSearch = new Search();
                aSearch.Flat = comboBoxFlat.Text;
                List<Search> searchList = new List<Search>();
                searchList = aSearch.FlatWiseBill();
                dataGridViewShow.DataSource = searchList;
            }
            else if (string.IsNullOrEmpty(comboBoxFlat.Text) && !string.IsNullOrEmpty(comboBoxDate.Text) && !string.IsNullOrEmpty(textBoxYear.Text))
            {
                Search aSearch = new Search();
                aSearch.Month = comboBoxDate.Text + " " + textBoxYear.Text;
                List<Search> searchList = new List<Search>();
                searchList = aSearch.MonthWiseBill();
                dataGridViewShow.DataSource = searchList;
            }
            else if (string.IsNullOrEmpty(comboBoxFlat.Text) && !string.IsNullOrEmpty(comboBoxDate.Text) && string.IsNullOrEmpty(textBoxYear.Text))
            {
                MessageBox.Show("Please Enter Year.");
            }
            else if (string.IsNullOrEmpty(comboBoxFlat.Text) && string.IsNullOrEmpty(comboBoxDate.Text) && !string.IsNullOrEmpty(textBoxYear.Text))
            {
                MessageBox.Show("Please Select Month.");
            }
            else
            {
                MessageBox.Show("Please select one of them.");
            }
        }

        private void buttonRefresh_Click(object sender, EventArgs e)
        {
            comboBoxFlat.SelectedIndex = -1;
            comboBoxDate.SelectedIndex = -1;
            textBoxYear.Text = "";
        }
    }
}
