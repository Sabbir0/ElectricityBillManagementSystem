﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using ElectricityBillCalculationApplication.Model;

namespace ElectricityBillCalculationApplication.Database
{
    public class DataAccess
    {

 
//=======================DataBase Insert================================
     
        public bool InsertBill(int presentUnit, 
                                 int previousUnit, 
                                 int totalUnit, 
                                 double totalUnitBill, 
                                 double serviceCharge,
                                 double demandCharge, 
                                 double Vat,
                                 double totalPaybleBill,
                                 int tanentID,
                                 string date)
        {
            string Connectionstring = ConfigurationManager.ConnectionStrings["DBConnection"].ToString();
            SqlConnection aConnection = new SqlConnection(Connectionstring);
            aConnection.Open();

            try
            {
                // insert value
                string InsertCommand = string.Format( "insert into ElectricityBillTable values( {0}, {1}, {2}, {3}, {4}, {5}, {6}, {7}, {8}, '{9}' )", 
                                                                                                 presentUnit , 
                                                                                                 previousUnit, 
                                                                                                 totalUnit, 
                                                                                                 totalUnitBill,
                                                                                                 serviceCharge,
                                                                                                 demandCharge,
                                                                                                 Vat,
                                                                                                 totalPaybleBill,
                                                                                                 tanentID,
                                                                                                 date);

                SqlCommand aCommand = new SqlCommand(InsertCommand, aConnection);
                aCommand.ExecuteNonQuery();


                return true;
            }
            catch
            {
                return false;
            }
            finally
            {
                // close connection
                aConnection.Close();
            }
        }
// Insert Payment
       public bool InsertPayment(double pay,
                                    double due, 
                                    string paymentDate,
                                    int billId)
        {
            string Connectionstring = ConfigurationManager.ConnectionStrings["DBConnection"].ToString();
            SqlConnection aConnection = new SqlConnection(Connectionstring);
            aConnection.Open();

            try
            {
                // insert value
                string InsertCommand = string.Format("insert into PaymentTable values( {0}, {1}, '{2}', {3} )", 
                                                                                pay,
                                                                                due,
                                                                                paymentDate,
                                                                                billId );
                                                                          

                SqlCommand aCommand = new SqlCommand(InsertCommand, aConnection);
                aCommand.ExecuteNonQuery();


                return true;
            }
            catch
            {
                return false;
            }
            finally
            {
                // close connection
                aConnection.Close();
            }
        }

//Insert Month
        public bool InsertMonth(string dateFrom,
                                string dateTo,
                                string monthName,
                                int billID)
        {
            string Connectionstring = ConfigurationManager.ConnectionStrings["DBConnection"].ToString();
            SqlConnection aConnection = new SqlConnection(Connectionstring);
            aConnection.Open();

            try
            {
                // insert value
                string InsertCommand = string.Format( "insert into MonthTable values( '{0}', '{1}', '{2}', {3} )",
                                                                                       dateFrom,
                                                                                       dateTo,
                                                                                       monthName,
                                                                                       billID);

                SqlCommand aCommand = new SqlCommand(InsertCommand, aConnection);
                aCommand.ExecuteNonQuery();


                return true;
            }
            catch
            {
                return false;
            }
            finally
            {
                // close connection
                aConnection.Close();
            }
        }

// Insert Tanent Information
        public bool InsertTanentInfo(string _TanentName, 
                                        string _Flat, 
                                        string _MeterNo)
        {
            string Connectionstring = ConfigurationManager.ConnectionStrings["DBConnection"].ToString();
            SqlConnection aConnection = new SqlConnection(Connectionstring);
            aConnection.Open();

            try
            {
                // insert value
                string InsertCommand =string.Format( "insert into TanentInfoTable values( '{0}', '{1}', '{2}' )",
                                                                                       _TanentName,
                                                                                        _Flat, 
                                                                                        _MeterNo );

                SqlCommand aCommand = new SqlCommand(InsertCommand, aConnection);
                aCommand.ExecuteNonQuery();


                return true;
            }
            catch
            {
                return false;
            }
            finally
            {
                // close connection
                aConnection.Close();
            }
        }

        public bool InsertVatAndCharge(double _serviceCharge,
                                        double _demandCharge,
                                        double _vatPercentage)
        {
            string Connectionstring = ConfigurationManager.ConnectionStrings["DBConnection"].ToString();
            SqlConnection aConnection = new SqlConnection(Connectionstring);
            aConnection.Open();

            try
            {
                // insert value
                string InsertCommand = string.Format("insert into VatAndChargeTable values( '{0}', '{1}', '{2}' )",
                                                                             _serviceCharge ,
                                                                             _demandCharge,
                                                                             _vatPercentage);

                SqlCommand aCommand = new SqlCommand(InsertCommand, aConnection);
                aCommand.ExecuteNonQuery();


                return true;
            }
            catch
            {
                return false;
            }
            finally
            {
                // close connection
                aConnection.Close();
            }
        }

        public bool InsertUnitPrice(double unitCostTill75,
                                    double unitCostTill200,
                                    double unitCostTill300, 
                                    double unitCostTill400,
                                    double unitCostTill600, 
                                    double unitCostMoreThan600)
        {
            string Connectionstring = ConfigurationManager.ConnectionStrings["DBConnection"].ToString();
            SqlConnection aConnection = new SqlConnection(Connectionstring);
            aConnection.Open();

            try
            {
                // insert value
                string InsertCommand = string.Format("insert into UnitCostTable values( '{0}', '{1}', '{2}', '{3}', '{4}', '{5}' )",
                                                                             unitCostTill75,
                                                                             unitCostTill200,
                                                                             unitCostTill300,
                                                                             unitCostTill400,
                                                                             unitCostTill600,
                                                                             unitCostMoreThan600);

                SqlCommand aCommand = new SqlCommand(InsertCommand, aConnection);
                aCommand.ExecuteNonQuery();


                return true;
            }
            catch
            {
                return false;
            }
            finally
            {
                // close connection
                aConnection.Close();
            }
        }




//========================Get From DataBase============================
        public DataSet GetMonth()
        {
            string Connectionstring = ConfigurationManager.ConnectionStrings["DBConnection"].ToString();
            SqlConnection aConnection = new SqlConnection(Connectionstring);
            aConnection.Open();

            string sql   =string.Format("SELECT * From MonthTable");
            SqlCommand aCommand = new SqlCommand(sql, aConnection);
            DataSet aDataSet = new DataSet();
            SqlDataAdapter aDataAdapter = new SqlDataAdapter(aCommand);

            aDataAdapter.Fill(aDataSet);



            // close connection
            aConnection.Close();
            return aDataSet;
        }

        public DataSet GetMonth(string month)
        {
            string Connectionstring = ConfigurationManager.ConnectionStrings["DBConnection"].ToString();
            SqlConnection aConnection = new SqlConnection(Connectionstring);
            aConnection.Open();

            SqlCommand aCommand = new SqlCommand("SELECT * From MonthTable "
                                                                + " WHERE MonthName = '"
                                                                        + month +"' "
                                                                        , aConnection);
            DataSet aDataSet = new DataSet();
            SqlDataAdapter aDataAdapter = new SqlDataAdapter(aCommand);

            aDataAdapter.Fill(aDataSet);

            // close connection
            aConnection.Close();
            return aDataSet;
        }
        public List<PayDue> GetPayDue(string flat, string month)
        {
            string Connectionstring = ConfigurationManager.ConnectionStrings["DBConnection"].ToString();
            SqlConnection aConnection = new SqlConnection(Connectionstring);
            aConnection.Open();

            List<PayDue> payDueList = new List<PayDue>();

            string query = string.Format("SELECT e.BillID, p.Pay, p.Due From PaymentTable p  "
                                                                           + " inner join ElectricityBillTable e "
                                                                           + " on p.BillID_FK = e.BillID "
                                                                           + " inner join TanentInfoTable t "
                                                                           + " on e.TanentID_FK = t.TanentID "
                                                                                               + " WHERE t.Flat = '"
                                                                                               + flat + "' AND e.MonthName = '"
                                                                                                + month + "' ");



            SqlCommand aCommand = new SqlCommand(query, aConnection);
            SqlDataReader aReader = aCommand.ExecuteReader();
            if (aReader.HasRows)
            {
                while (aReader.Read())
                {
                    PayDue aPayDue = new PayDue();
                    aPayDue.BillId = Convert.ToInt32(aReader[0]);
                    aPayDue.Pay = Convert.ToDouble(aReader[1]);
                    aPayDue.Due = Convert.ToDouble(aReader[2]);

                    payDueList.Add(aPayDue);
                }
               
            }


            // close connection
            aConnection.Close();
            return payDueList;
        }
        public List<DueBill> GetDue()
        {
            string Connectionstring = ConfigurationManager.ConnectionStrings["DBConnection"].ToString();
            SqlConnection aConnection = new SqlConnection(Connectionstring);
            aConnection.Open();
            List<DueBill> dueBillList = new List<DueBill>();
            string query = string.Format("SELECT e.BillID,t.TanentName, t.Flat, e.MonthName, p.Due From PaymentTable p  "
                                                                          + "join ElectricityBillTable e "
                                                                          + " on p.BillID_FK = e.BillID "
                                                                          + "join TanentInfoTable t "
                                                                          + " on e.TanentID_FK = t.TanentID "
                                                                                              + " WHERE Due > '"
                                                                                              + 0 + "'  ");

            SqlCommand aCommand = new SqlCommand(query, aConnection);
            SqlDataReader aReader = aCommand.ExecuteReader();
            if (aReader.HasRows)
            {
                while (aReader.Read())
                {
                    DueBill aDueBill = new DueBill();
                    aDueBill.BillId =Convert.ToInt32(aReader[0]);
                    aDueBill.TanentName = aReader[1].ToString();
                    aDueBill.Flat = aReader[2].ToString();
                    aDueBill.Month = aReader[3].ToString();
                    aDueBill.BillDue = Convert.ToDouble(aReader[4]);
                    dueBillList.Add(aDueBill);
                }
            }


            // close connection
            aConnection.Close();
            return dueBillList;
        }
        public List<AdjustDue> GetDue(int BillID)
        {
            string Connectionstring = ConfigurationManager.ConnectionStrings["DBConnection"].ToString();
            SqlConnection aConnection = new SqlConnection(Connectionstring);
            aConnection.Open();
           
            List<AdjustDue> adjustDueList = new List<AdjustDue>();

           string query = string.Format ("SELECT e.BillID, e.MonthName, "
                                                       + " t.Flat, "
                                                       + " t.TanentName, "
                                                       + " e.TotalPayble, "
                                                       + " p.Pay, p.Due From PaymentTable p  "
                                                                          + " inner join ElectricityBillTable e "
                                                                          + " on p.BillID_FK = e.BillID "
                                                                          + " inner join TanentInfoTable t "
                                                                          + " on e.TanentID_FK = t.TanentID "
                                                                                              + " WHERE BillID = "
                                                                                              + BillID + "  ");
                                                                                            


            SqlCommand aCommand = new SqlCommand(query, aConnection);
            SqlDataReader aReader = aCommand.ExecuteReader();
            if (aReader.HasRows)
            {
                while (aReader.Read())
                {
                    AdjustDue aAdjustDue = new AdjustDue();

                    aAdjustDue.BillId =Convert.ToInt32(aReader[0]);
                    aAdjustDue.Month = Convert.ToString(aReader[1]);
                    aAdjustDue.Flat = Convert.ToString(aReader[2]);
                    aAdjustDue.TanentName = Convert.ToString(aReader[3]);
                    aAdjustDue.TotalPayble = Convert.ToDouble(aReader[4]);
                    aAdjustDue.Pay = Convert.ToDouble(aReader[5]);
                    aAdjustDue.PreviousDue = Convert.ToDouble(aReader[6]);

                    adjustDueList.Add(aAdjustDue);
                }
            }

         
            // close connection
            aConnection.Close();
            return adjustDueList;

        }
       
        public int GetBillID(int TanentID,
                             string monthName)
        {
            string Connectionstring = ConfigurationManager.ConnectionStrings["DBConnection"].ToString();
            SqlConnection aConnection = new SqlConnection(Connectionstring);
            aConnection.Open();
            
            string query = string.Format("SELECT BillID From ElectricityBillTable "
                                                         + " WHERE TanentID_FK = " 
                                                         + TanentID + " AND MonthName = '"
                                                         + monthName + "' ");

            SqlCommand aCommand = new SqlCommand(query, aConnection);
           SqlDataReader aReader = aCommand.ExecuteReader();
            if (aReader.HasRows)
            {
                MonthInfo aMonthInfo = new MonthInfo();
                while (aReader.Read())
                {
                   
                    aMonthInfo.BillId = Convert.ToInt32(aReader[0]);
                    
                }
                return aMonthInfo.BillId;
            }
            // close connection
            aConnection.Close();
            return 0;
        }
        public int GetBillID(string flat, 
                              string month)
        {
            string Connectionstring = ConfigurationManager.ConnectionStrings["DBConnection"].ToString();
            SqlConnection aConnection = new SqlConnection(Connectionstring);
            aConnection.Open();

            string query = string.Format("SELECT BillID From ElectricityBillTable "
                                                + " inner join TanentInfoTable on TanentID_FK = TanentID "
                                                         + " WHERE Flat = '"
                                                         + flat + "' AND MonthName = '"
                                                         + month + "' ");

            SqlCommand aCommand = new SqlCommand(query, aConnection);
            SqlDataReader aReader = aCommand.ExecuteReader();
            if (aReader.HasRows)
            {
                AdjustDue aAdjustDue = new AdjustDue();
                while (aReader.Read())
                {
                    aAdjustDue.BillId = Convert.ToInt32(aReader[0]);
                }
                return aAdjustDue.BillId;
            }
            // close connection
            aConnection.Close();
            return 0;
        }
        public List<PreviewBill> GetBill(string month,
                                        int tanentID)
        {
            string Connectionstring = ConfigurationManager.ConnectionStrings["DBConnection"].ToString();
            SqlConnection aConnection = new SqlConnection(Connectionstring);
            aConnection.Open();

            List<PreviewBill> previewBillList = new List<PreviewBill>();
            string query = string.Format("SELECT e.BillID, e.PreviousUnit,"
                                             + " e.PresentUnit,"
                                             + " e.TotalUnit,"
                                             + " e.UnitBill,"
                                             + " e.ServiceCharge,"
                                             + " e.DemandCharge, "
                                             + " e.Vat,"
                                             + " e.TotalPayble,"
                                             + " t.Flat," 
                                             + " t.TanentName, "
                                             + " t.MeterNo,"
                                             + " m.DateFrom,"
                                             + " m.DateTo, m.MonthName From MonthTable m  "
                                                                          + " inner join ElectricityBillTable e "
                                                                          + " on m.BillID_FK = e.BillID "
                                                                          + " inner join TanentInfoTable t "
                                                                          + " on e.TanentID_FK = t.TanentID "
                                                                                              + " WHERE e.MonthName = '"
                                                                                              + month + "' AND TanentID = "
                                                                                              + tanentID + " ");
                                                                                           
            SqlCommand aCommand = new SqlCommand(query, aConnection);

            SqlDataReader aReader = aCommand.ExecuteReader();
            if (aReader.HasRows)
            {
                while (aReader.Read())
                {
                    PreviewBill aPreviewBill = new PreviewBill();
                    aPreviewBill.BillId = Convert.ToInt32(aReader[0]);
                    aPreviewBill.PreviousUnit = Convert.ToInt32(aReader[1]);
                    aPreviewBill.PresentUnit = Convert.ToInt32(aReader[2]);
                    aPreviewBill.TotalUnit = Convert.ToInt32(aReader[3]);
                    aPreviewBill.UnitBill = Convert.ToDouble(aReader[4]);
                    aPreviewBill.ServiceCharge = Convert.ToDouble(aReader[5]);
                    aPreviewBill.DemandCharge = Convert.ToDouble(aReader[6]);
                    aPreviewBill.Vat = Convert.ToDouble(aReader[7]);
                    aPreviewBill.TotalPayble = Convert.ToDouble(aReader[8]);
                    
                    aPreviewBill.Flat = Convert.ToString(aReader[9]);
                    aPreviewBill.TanentName = Convert.ToString(aReader[10]);
                    aPreviewBill.MeterNo = Convert.ToString(aReader[11]);

                    aPreviewBill.DateFrom = Convert.ToString(aReader[12]);
                    aPreviewBill.DateTo = Convert.ToString(aReader[13]);
                    aPreviewBill.MonthName = Convert.ToString(aReader[14]);

                    previewBillList.Add(aPreviewBill);
                }
            }

            // close connection
            aConnection.Close();
            return previewBillList;

        }
        public DataSet GetTanentInfo()
        {
            string Connectionstring = ConfigurationManager.ConnectionStrings["DBConnection"].ToString();
            SqlConnection aConnection = new SqlConnection(Connectionstring);
            aConnection.Open();

            string sql = string.Format("SELECT * From TanentInfoTable");
            SqlCommand aCommand = new SqlCommand(sql, aConnection);
            DataSet aDataSet = new DataSet();
            SqlDataAdapter aDataAdapter = new SqlDataAdapter(aCommand);

            aDataAdapter.Fill(aDataSet);


            // close connection
            aConnection.Close();
            return aDataSet;
        }

        public DataSet GetTanentInfo(int SelectTanent)
        {
            string Connectionstring = ConfigurationManager.ConnectionStrings["DBConnection"].ToString();
            SqlConnection aConnection = new SqlConnection(Connectionstring);
            aConnection.Open();

            SqlCommand aCommand = new SqlCommand("SELECT * From TanentInfoTable "
                                                                    + " WHERE TanentID = "
                                                                                + SelectTanent + " "
                                                                                      , aConnection);
            DataSet aDataSet = new DataSet();
            SqlDataAdapter aDataAdapter = new SqlDataAdapter(aCommand);

            aDataAdapter.Fill(aDataSet);



            // close connection
            aConnection.Close();
            return aDataSet;
        }
        public List<TanentInfo> GetTanentInfo(string flat)
        {
            string Connectionstring = ConfigurationManager.ConnectionStrings["DBConnection"].ToString();
            SqlConnection aConnection = new SqlConnection(Connectionstring);
            aConnection.Open();
            List<TanentInfo> tanentInfoList = new List<TanentInfo>();
            string query = string.Format("SELECT TanentName From TanentInfoTable "
                                                                    + " where Flat ='"
                                                                                    + flat +"' ");

            SqlCommand aCommand = new SqlCommand(query, aConnection);
            SqlDataReader aReader = aCommand.ExecuteReader();
            if (aReader.HasRows)
            {
                while (aReader.Read())
                {
                    TanentInfo aTanent = new TanentInfo();
                    aTanent.TanentName = Convert.ToString(aReader[0]);
                    tanentInfoList.Add(aTanent);
                }
            }


            // close connection
            aConnection.Close();
            return tanentInfoList;
        }
        public List<VatAndCharge> GetVatAndCharge()
        {
            string Connectionstring = ConfigurationManager.ConnectionStrings["DBConnection"].ToString();
            SqlConnection aConnection = new SqlConnection(Connectionstring);
            aConnection.Open();
            List<VatAndCharge> vatAndChargeList = new List<VatAndCharge>();
            string query = string.Format("SELECT * From VatAndChargeTable ");

            SqlCommand aCommand = new SqlCommand(query, aConnection);
            SqlDataReader aReader = aCommand.ExecuteReader();
            if (aReader.HasRows)
            {
                while (aReader.Read())
                {
                    VatAndCharge aVatAndCharge = new VatAndCharge();
                    aVatAndCharge.VatAndChargeId = Convert.ToInt32(aReader[0]);
                    aVatAndCharge.ServiceCharge = Convert.ToDouble(aReader[1]);
                    aVatAndCharge.DemandCharge = Convert.ToDouble(aReader[2]);
                    aVatAndCharge.VatPercentage = Convert.ToDouble(aReader[3]);

                    vatAndChargeList.Add(aVatAndCharge);
                }
            }


            // close connection
            aConnection.Close();
            return vatAndChargeList;
        }
        public List<UnitPrice> GetUnitPrice()
        {
            string Connectionstring = ConfigurationManager.ConnectionStrings["DBConnection"].ToString();
            SqlConnection aConnection = new SqlConnection(Connectionstring);
            aConnection.Open();
            List<UnitPrice> unitPriceList = new List<UnitPrice>();
            string query = string.Format("SELECT * From UnitCostTable ");

            SqlCommand aCommand = new SqlCommand(query, aConnection);
            SqlDataReader aReader = aCommand.ExecuteReader();
            if (aReader.HasRows)
            {
                while (aReader.Read())
                {
                    UnitPrice aUnitPrice = new UnitPrice();
                    aUnitPrice.UnitPriceId = Convert.ToInt32(aReader[0]);
                    aUnitPrice.UnitCostTill75 = Convert.ToDouble(aReader[1]);
                    aUnitPrice.UnitCostTill200 = Convert.ToDouble(aReader[2]);
                    aUnitPrice.UnitCostTill300 = Convert.ToDouble(aReader[3]);
                    aUnitPrice.UnitCostTill400 = Convert.ToDouble(aReader[4]);
                    aUnitPrice.UnitCostTill600 = Convert.ToDouble(aReader[5]);
                    aUnitPrice.UnitCostMoreThan600 = Convert.ToDouble(aReader[6]);

                    unitPriceList.Add(aUnitPrice);
                }
            }


            // close connection
            aConnection.Close();
            return unitPriceList;
        }
        public List<Search> GetFlatWiseBill(string _flat)
        {
            string Connectionstring = ConfigurationManager.ConnectionStrings["DBConnection"].ToString();
            SqlConnection aConnection = new SqlConnection(Connectionstring);
            aConnection.Open();

            List<Search> searchList = new List<Search>();

            string query = string.Format("SELECT e.BillID, t.TanentName, t.Flat, e.MonthName, e.TotalUnit, e.TotalPayble,  p.Pay, p.Due, p.PaymentDate From PaymentTable p  "
                                                                           + " inner join ElectricityBillTable e "
                                                                           + " on p.BillID_FK = e.BillID "
                                                                           + " inner join TanentInfoTable t "
                                                                           + " on e.TanentID_FK = t.TanentID "
                                                                                               + " WHERE t.Flat = '"
                                                                                               + _flat + "'  ");



            SqlCommand aCommand = new SqlCommand(query, aConnection);
            SqlDataReader aReader = aCommand.ExecuteReader();
            if (aReader.HasRows)
            {
                while (aReader.Read())
                {
                    Search aSearch = new Search();
                    aSearch.BillId = Convert.ToInt32(aReader[0]);
                    aSearch.TanentName = Convert.ToString(aReader[1]);
                    aSearch.Flat = Convert.ToString(aReader[2]);
                    aSearch.Month = Convert.ToString(aReader[3]);
                    aSearch.TotalUnit = Convert.ToInt32(aReader[4]);
                    aSearch.TotalPayble = Convert.ToDouble(aReader[5]);
                    double paybill = aSearch.Pay = Convert.ToDouble(aReader[6]);
                    aSearch.Due = Convert.ToDouble(aReader[7]);
                    

                    if (paybill == 0)
                    {
                        aSearch.PaymentDate = "No Payment Yet";                        
                    }
                    else
                    {
                        aSearch.PaymentDate = Convert.ToString(aReader[8]);
                    }

                    

                    searchList.Add(aSearch);
                }
            }
            // close connection
            aConnection.Close();
            return searchList;
        }
        public List<Search> GetMonthWiseBill(string _month)
        {
            string Connectionstring = ConfigurationManager.ConnectionStrings["DBConnection"].ToString();
            SqlConnection aConnection = new SqlConnection(Connectionstring);
            aConnection.Open();

            List<Search> searchList = new List<Search>();

            string query = string.Format("SELECT e.BillID, t.TanentName, t.Flat, e.MonthName, e.TotalUnit, e.TotalPayble,  p.Pay, p.Due, p.PaymentDate From PaymentTable p  "
                                                                           + " inner join ElectricityBillTable e "
                                                                           + " on p.BillID_FK = e.BillID "
                                                                           + " inner join TanentInfoTable t "
                                                                           + " on e.TanentID_FK = t.TanentID "
                                                                                               + " WHERE e.MonthName = '"
                                                                                               + _month + "'  ");



            SqlCommand aCommand = new SqlCommand(query, aConnection);
            SqlDataReader aReader = aCommand.ExecuteReader();
            if (aReader.HasRows)
            {
                while (aReader.Read())
                {
                    Search aSearch = new Search();
                    aSearch.BillId = Convert.ToInt32(aReader[0]);
                    aSearch.TanentName = Convert.ToString(aReader[1]);
                    aSearch.Flat = Convert.ToString(aReader[2]);
                    aSearch.Month = Convert.ToString(aReader[3]);
                    aSearch.TotalUnit = Convert.ToInt32(aReader[4]);
                    aSearch.TotalPayble = Convert.ToDouble(aReader[5]);
                    double paybill = aSearch.Pay = Convert.ToDouble(aReader[6]);
                    aSearch.Due = Convert.ToDouble(aReader[7]);             

                    if (paybill == 0)
                    {
                        aSearch.PaymentDate = "No Payment Yet";
                    }
                    else
                    {
                        aSearch.PaymentDate = Convert.ToString(aReader[8]);
                    }


                    searchList.Add(aSearch);
                }
            }
            // close connection
            aConnection.Close();
            return searchList;
        }


//====================Update Database=============================
        public bool UpdateTanent(string Name, 
                                 string Flat, 
                                 string MeterNo)
        {
            string Connectionstring = ConfigurationManager.ConnectionStrings["DBConnection"].ToString();
            SqlConnection aConnection = new SqlConnection(Connectionstring);
            aConnection.Open();


            // insert value
            string UpdateCommand = "update TanentInfoTable set TanentName = '" + Name + "', Flat = '"
                                                                         + Flat + "', MeterNo = '"
                                                                         + MeterNo + "' where Flat = '"
                                                                         + Flat + "' ";
            SqlCommand aCommand = new SqlCommand(UpdateCommand, aConnection);
            aCommand.ExecuteNonQuery();
            // close connection
            aConnection.Close();
            return true;
        }


        public bool DueUpdate(int billId,
                                double adjustDue,
                                double updatePay)
        {
            string Connectionstring = ConfigurationManager.ConnectionStrings["DBConnection"].ToString();
            SqlConnection aConnection = new SqlConnection(Connectionstring);
            aConnection.Open();


            // Update value
            string UpdateCommand =string.Format( "update PaymentTable set Due = '" + adjustDue + "', Pay = '"
                                                                         + updatePay + "', PaymentDate = '" 
                                                                           + DateTime.Now + "' where BillId_FK = "
                                                                         + billId + " ");
            SqlCommand aCommand = new SqlCommand(UpdateCommand, aConnection);
            aCommand.ExecuteNonQuery();
            // close connection
            aConnection.Close();
            return true;
        }

        public bool UpdateVatAndCharge(int vatAndChargeId,
                                       double serviceCharge,
                                       double demandCharge,
                                       double vatPercentage)
        {

            string Connectionstring = ConfigurationManager.ConnectionStrings["DBConnection"].ToString();
            SqlConnection aConnection = new SqlConnection(Connectionstring);
            aConnection.Open();


            // insert value
            string UpdateCommand = "update VatAndChargeTable set ServiceCharge = " + serviceCharge + ", DemandCharge = "
                                                                         + demandCharge + ", VatPercentage = "
                                                                         + vatPercentage + " where ChargeID = "
                                                                         + vatAndChargeId + " ";
            SqlCommand aCommand = new SqlCommand(UpdateCommand, aConnection);
            aCommand.ExecuteNonQuery();
            // close connection
            aConnection.Close();
            return true;
        }

        public bool UpdateUnitPrice(int _unitPriceId,
                                    double _unitCostTill75, 
                                    double _unitCostTill200, 
                                    double _unitCostTill300, 
                                    double _unitCostTill400,        
                                    double _unitCostTill600, 
                                    double _unitCostMoreThan600)
        {
            string Connectionstring = ConfigurationManager.ConnectionStrings["DBConnection"].ToString();
            SqlConnection aConnection = new SqlConnection(Connectionstring);
            aConnection.Open();


            // insert value
            string UpdateCommand = "update UnitCostTable set UnitCostTill75 = " + _unitCostTill75 + ", UnitCostTill200 = "
                                                                         + _unitCostTill200 + ", UnitCostTill300 = "
                                                                         + _unitCostTill300 + ", UnitCostTill400 = "
                                                                         + _unitCostTill400 + ", UnitCostTill600 = "
                                                                         + _unitCostTill600 + ", UnitCostMoreThan600 = "
                                                                         + _unitCostMoreThan600 + " where UnitCostId = "
                                                                         + _unitPriceId + " ";
            SqlCommand aCommand = new SqlCommand(UpdateCommand, aConnection);
            aCommand.ExecuteNonQuery();
            // close connection
            aConnection.Close();
            return true;
        }



























    }
}
