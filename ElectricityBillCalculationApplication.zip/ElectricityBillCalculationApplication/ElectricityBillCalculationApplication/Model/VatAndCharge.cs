﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using ElectricityBillCalculationApplication.Database;

namespace ElectricityBillCalculationApplication.Model
{
  public class VatAndCharge
    {
      DataAccess aDataAccess = new DataAccess();

      private int _vatAndChargeId = 0;
      private double _serviceCharge = 0;
      private double _demandCharge = 0;
      private double _vatPercentage = 0;

      public int VatAndChargeId
      {
          get { return _vatAndChargeId; }
          set { _vatAndChargeId = value; }
      }
      public double ServiceCharge
      {
          get { return _serviceCharge; }
          set { _serviceCharge = value; }
      }
      public double DemandCharge
      {
          get { return _demandCharge; }
          set { _demandCharge = value; }
      }
      public double VatPercentage
      {
          get { return _vatPercentage; }
          set { _vatPercentage = value; }
      }

      public void AddVatAndCharge()
      {
          aDataAccess.InsertVatAndCharge(_serviceCharge,
                                        _demandCharge,
                                        _vatPercentage);
      }
      public List<VatAndCharge> VatCharge()
      {
          return aDataAccess.GetVatAndCharge();
      }

      public void UpdateVatCharge(int vatAndChargeId,
                                    double serviceCharge,
                                    double demandCharge,
                                    double vatPercentage)
      {
         aDataAccess.UpdateVatAndCharge(vatAndChargeId, serviceCharge, demandCharge, vatPercentage);
      }
    }
}
