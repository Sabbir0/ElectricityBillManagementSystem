﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ElectricityBillCalculationApplication.Database;
using System.Data;


namespace ElectricityBillCalculationApplication.Model
{
   public class ElectricityCalculator
    {
        private int presentUnit = 0;
        private int previousUnit = 0;

        private static int totalUnit = 0;

        private double unitCostTill75 = 0;
        private double unitCostTill200 = 0;
        private double unitCostTill300 = 0;
        private double unitCostTill400 = 0;
        private double unitCostTill600 = 0;

        private double demandCharge = 0;
        private double serviceCharge = 0;
        private double vatPercentage = 0;

        private static double vatTotal;
        private static double totalBill;
        private static double totalUnitBillTill75;
        private static double totalPayble;
        private static double totalUnitBillTill200;
        private static double totalUnitBillTill300;
        private static double totalUnitBillTill400;
        private static double totalUnitBillTill600;

        private int tanentID = 0;
        private string date = "";

// Set get

        public static double TotalPayble
        {
            get { return ElectricityCalculator.totalPayble; }
            set
            { 
                ElectricityCalculator.totalPayble = value;
                ElectricityCalculator.totalPayble = Math.Round(ElectricityCalculator.totalPayble, 2, MidpointRounding.AwayFromZero);
              
            }
        }
        public static double TotalBill
        {
            get { return ElectricityCalculator.totalBill; }
            set
            { 
                ElectricityCalculator.totalBill = value;
                ElectricityCalculator.totalBill = Math.Round(ElectricityCalculator.totalBill, 2, MidpointRounding.AwayFromZero);
            }
        }
        public double UnitCostTill600
        {
            get { return unitCostTill600; }
            set { unitCostTill600 = value; }
        }
        public double UnitCostTill400
        {
            get { return unitCostTill400; }
            set { unitCostTill400 = value; }
        }
        public double UnitCostTill300
        {
            get { return unitCostTill300; }
            set { unitCostTill300 = value; }
        }
        public double UnitCostTill200
        {
            get { return unitCostTill200; }
            set { unitCostTill200 = value; }
        }
        public double UnitCostTill75
        {
            get { return unitCostTill75; }
            set { unitCostTill75 = value; }
        }
        public int PreviousUnit
        {
            get { return previousUnit; }
            set { previousUnit = value; }
        }
        public int PresentUnit
        {
            get { return presentUnit; }
            set { presentUnit = value; }
        }
        public double VatPercentage
        {
            get { return vatPercentage; }
            set { vatPercentage = value; }
        }
        public double ServiceCharge
        {
            get { return serviceCharge; }
            set { serviceCharge = value; }
        }
        public double DemandCharge
        {
            get { return demandCharge; }
            set { demandCharge = value; }
        }
        public string Date
        {
            get { return date; }
            set { date = value; }
        }
        public int TanentID
        {
            get { return tanentID; }
            set { tanentID = value; }
        }

       //totalPayble = Math.Round(totalPayble, 2, MidpointRounding.AwayFromZero);
// Method
        public int TotalUnit()
        {
            totalUnit = presentUnit - previousUnit;
            return totalUnit;
        }

        public double TotalUnitBill()
        {
            // 0-75
             if( totalUnit >=0 && totalUnit <=75 ){

                 return unitCostTill75 * totalUnit ;
             }
            //76-200
            else if(totalUnit >75 && totalUnit <= 200){
                totalUnitBillTill75 = 75 * unitCostTill75;
                totalUnitBillTill200 = (totalUnit - 75) * unitCostTill200;
                totalBill = totalUnitBillTill75 + totalUnitBillTill200;
                return totalBill;
            }
            //201-300
             else if(totalUnit >200 && totalUnit <= 300){
                totalUnitBillTill75 = 75 * unitCostTill75;
                totalUnitBillTill200 = (200 - 75 ) * unitCostTill200;
                totalUnitBillTill300 = (totalUnit - 200) * unitCostTill300;
                totalBill = totalUnitBillTill75 + totalUnitBillTill200 + totalUnitBillTill300;
                return totalBill;
             }
            //301-400
            else if(totalUnit >300 && totalUnit <= 400){
                totalUnitBillTill75 = 75 * unitCostTill75;
                totalUnitBillTill200 = (200 - 75 ) * unitCostTill200;
                totalUnitBillTill300 = (300 - 200) * unitCostTill300;
                totalUnitBillTill400 = (totalUnit - 300 ) * unitCostTill400;
                totalBill = totalUnitBillTill75 + totalUnitBillTill200
                    + totalUnitBillTill300 + totalUnitBillTill400;
                return totalBill;
            }
            //401-600
            else if(totalUnit >400 && totalUnit <= 600){
                totalUnitBillTill75 = 75 * unitCostTill75;
                totalUnitBillTill200 = (200 - 75 ) * unitCostTill200;
                totalUnitBillTill300 = (300 - 200) * unitCostTill300;
                totalUnitBillTill400 = (400 - 300 ) * unitCostTill400;
                totalUnitBillTill600 = (totalUnit - 400) * unitCostTill600;
                totalBill = totalUnitBillTill75 + totalUnitBillTill200
                    + totalUnitBillTill300 + totalUnitBillTill400 +
                    totalUnitBillTill600;
                return totalBill;
            }
                 // more than 600
             else
             {
                 totalUnitBillTill75 = 75 * unitCostTill75;
                 totalUnitBillTill200 = (200 - 75) * unitCostTill200;
                 totalUnitBillTill300 = (300 - 200) * unitCostTill300;
                 totalUnitBillTill400 = (400 - 300) * unitCostTill400;
                 totalUnitBillTill600 = (totalUnit - 400) * unitCostTill600;
                 totalBill = totalUnitBillTill75 + totalUnitBillTill200
                     + totalUnitBillTill300 + totalUnitBillTill400 +
                     totalUnitBillTill600;
                 return totalBill;
             }

            return 0;
        }

        public double VatCalculator(){

          vatTotal = ((vatPercentage * TotalUnitBill()) / 100) ;
          vatTotal = Math.Round(vatTotal, 2, MidpointRounding.AwayFromZero);
            return vatTotal ;
        }

        public double TotalPaybleBill(){
            totalPayble = TotalUnitBill() + demandCharge + serviceCharge + VatCalculator() ;
            return totalPayble;
        }

        public void AddBill()
        {
            DataAccess aDataAccess = new DataAccess();
            aDataAccess.InsertBill(presentUnit,
                                   previousUnit,
                                   totalUnit,
                                   TotalUnitBill(),
                                   serviceCharge,
                                   demandCharge,
                                   VatCalculator(),
                                   TotalPaybleBill(),
                                   tanentID,
                                   date);
                                

        }



    }
}
