﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ElectricityBillCalculationApplication.Database;

namespace ElectricityBillCalculationApplication.Model
{
   public class AdjustDueButtton
    {


       public int BillId = 0;
        private double _previousDue = 0;
        private double _adjustedDue = 0;
        private double _pay = 0;

        public double Pay
        {
            get { return _pay; }
            set
            {
                _pay = Math.Round(_pay, 2, MidpointRounding.AwayFromZero);
                _pay = value;
            }
        }
        public double AdjustedDue
        {
            get { return _adjustedDue; }
            set
            {
                _adjustedDue = Math.Round(_adjustedDue, 2, MidpointRounding.AwayFromZero);
                _adjustedDue = value;

            }
        }
        public double PreviousDue
        {
            get { return _previousDue; }
            set
            {
                _previousDue = Math.Round(_previousDue, 2, MidpointRounding.AwayFromZero);
                _previousDue = value;

            }
        }


        public double DueAdjust()
        {
            return (Math.Round(_previousDue - _adjustedDue, 2, MidpointRounding.AwayFromZero));
        }
        public double UpdatePay()
        {
            return (_pay + _adjustedDue);
        }
        public void UpdateDue()
        {
            DataAccess aDataAccess = new DataAccess();
            aDataAccess.DueUpdate( BillId,
                                    DueAdjust(),
                                    UpdatePay());
        }



    }
}
