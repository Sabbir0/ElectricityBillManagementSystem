﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using ElectricityBillCalculationApplication.Database;

namespace ElectricityBillCalculationApplication.Model
{
   public class BillPayment
    {
        private double pay = 0;
        private double due = 0;
        private double totalPayble = 0;
        private int billId = 0;
        private string _paymentDate = "";

        public string PaymentDate
        {
            get { return _paymentDate; }
            set { _paymentDate = value; }
        }

        public int BillId
        {
            get { return billId; }
            set { billId = value; }
        }

        public double TotalPayble
        {
            get { return totalPayble; }
            set { totalPayble = value; }
        }

        public double Pay
        {
            get { return pay; }
            set { pay = value; }
        }

        public double Due
        {
            get { return due; }
            set
            { 
                due = value;
                due = Math.Round(due, 2, MidpointRounding.AwayFromZero);
            }
        }

       public double DueCalculator()
        {
            return totalPayble - pay;
        }

       public void AddPayment()
       {
           DataAccess aDataAccess = new DataAccess();
           aDataAccess.InsertPayment(Pay,
                                     DueCalculator(),
                                     _paymentDate,
                                     billId);
       }
       
    }
}
