﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ElectricityBillCalculationApplication.Database;
using System.Data;

namespace ElectricityBillCalculationApplication.Model
{
    public class DueBill
    {
        private int _billId = 0;
        private string _tanentName = "";
        private string _flat = "";
        private string _month = "";
        private double _billDue = 0;

        public int BillId
        {
            get { return _billId; }
            set { _billId = value; }
        }
        public string TanentName
        {
            get { return _tanentName; }
            set { _tanentName = value; }
        }
        public string Flat
        {
            get { return _flat; }
            set { _flat = value; }
        }
        public string Month
        {
            get { return _month; }
            set { _month = value; }
        }
        public double BillDue
        {
            get { return _billDue; }
            set { 
                _billDue = value;
                _billDue = Math.Round(_billDue, 2, MidpointRounding.AwayFromZero);
            }
        }
      

        public List<DueBill> Due()
        {
           DataAccess aDataAccess = new DataAccess();
           return aDataAccess.GetDue();
        }



       
    }
}
