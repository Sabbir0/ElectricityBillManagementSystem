﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ElectricityBillCalculationApplication.Database;

namespace ElectricityBillCalculationApplication.Model
{
   public class UnitPrice
    {
        private double unitCostTill75 = 0;
        private double unitCostTill200 = 0;
        private double unitCostTill300 = 0;
        private double unitCostTill400 = 0;
        private double unitCostTill600 = 0;
        private double unitCostMoreThan600 = 0;
        private int unitPriceId = 0;

        public int UnitPriceId
        {
            get { return unitPriceId; }
            set { unitPriceId = value; }
        }



        public double UnitCostTill75
        {
            get { return unitCostTill75; }
            set { unitCostTill75 = value; }
        }       
        public double UnitCostTill200
        {
            get { return unitCostTill200; }
            set { unitCostTill200 = value; }
        }      
        public double UnitCostTill300
        {
            get { return unitCostTill300; }
            set { unitCostTill300 = value; }
        }
        public double UnitCostTill400
        {
            get { return unitCostTill400; }
            set { unitCostTill400 = value; }
        }       
        public double UnitCostTill600
        {
            get { return unitCostTill600; }
            set { unitCostTill600 = value; }
        }
        public double UnitCostMoreThan600
        {
            get { return unitCostMoreThan600; }
            set { unitCostMoreThan600 = value; }
        }

        DataAccess aDataAccess = new DataAccess();
        public void AddUnitPrice()
        {
            aDataAccess.InsertUnitPrice(unitCostTill75,
                                          unitCostTill200,
                                          unitCostTill300,
                                          unitCostTill400,
                                          unitCostTill600,
                                          unitCostMoreThan600);
        }
        public List<UnitPrice> UnitCost()
        {
            return aDataAccess.GetUnitPrice();
        }
       
        public void UnitPriceUpdate(int _unitPriceId,
                                      double _unitCostTill75,
                                      double _unitCostTill200,
                                      double _unitCostTill300,
                                      double _unitCostTill400,
                                      double _unitCostTill600,
                                      double _unitCostMoreThan600)
        {
            aDataAccess.UpdateUnitPrice( _unitPriceId,
                                         _unitCostTill75,
                                         _unitCostTill200,
                                         _unitCostTill300,
                                         _unitCostTill400,
                                         _unitCostTill600,
                                         _unitCostMoreThan600);
        }                              


    }
}
