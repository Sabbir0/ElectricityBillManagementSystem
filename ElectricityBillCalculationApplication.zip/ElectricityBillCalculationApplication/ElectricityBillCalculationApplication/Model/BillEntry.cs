﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace ElectricityBillCalculationApplication.Model
{
   public class BillEntry
    {
        private int _billId = 0;
        private int _previousUnit = 0;
        private int _presentUnit = 0;
        private int _totalUnit = 0;
        private double _unitBill = 0;
        private double _serviceCharge = 0;
        private double _demandCharge = 0;
        private double _vat = 0;
        private double _totalPayble = 0;
        private int _tanentId = 0;
        private string _monthName = "";

        public int TanentId
        {
            get { return _tanentId; }
            set { _tanentId = value; }
        }

        public string MonthName
        {
            get { return _monthName; }
            set { _monthName = value; }
        }

        public double TotalPayble
        {
            get { return _totalPayble; }
            set { _totalPayble = value; }
        }

        public double Vat
        {
            get { return _vat; }
            set { _vat = value; }
        }
        public double DemandCharge
        {
            get { return _demandCharge; }
            set { _demandCharge = value; }
        }
        public double ServiceCharge
        {
          get { return _serviceCharge; }
          set { _serviceCharge = value; }
        }
        public double UnitBill
        {
            get { return _unitBill; }
            set { _unitBill = value; }
        }
        public int TotalUnit
        {
            get { return _totalUnit; }
            set { _totalUnit = value; }
        }
        public int PresentUnit
        {
            get { return _presentUnit; }
            set { _presentUnit = value; }
        }
        public int PreviousUnit
        {
            get { return _previousUnit; }
            set { _previousUnit = value; }
        }
        public int BillId
        {
            get { return _billId; }
            set { _billId = value; }
        }



    }
}
