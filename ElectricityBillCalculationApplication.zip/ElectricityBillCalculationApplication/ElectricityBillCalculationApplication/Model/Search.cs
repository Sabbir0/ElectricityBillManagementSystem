﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ElectricityBillCalculationApplication.Database;

namespace ElectricityBillCalculationApplication.Model
{
   public class Search
    {
 
        private int _billId = 0;
        private string _tanentName = "";
        private string _flat = "";
        private int _totalUnit = 0;
        private double _totalPayble = 0;
        private double _pay = 0;
        private double _due = 0;
        private string _month = "";
        private string _paymentDate = "";

        public int BillId
        {
            get { return _billId; }
            set { _billId = value; }
        }
        public string TanentName
        {
            get { return _tanentName; }
            set { _tanentName = value; }
        }
        public string Flat
        {
            get { return _flat; }
            set { _flat = value; }
        }
        public string Month
        {
            get { return _month; }
            set { _month = value; }
        }
        public int TotalUnit
        {
            get { return _totalUnit; }
            set { _totalUnit = value; }
        }
        public double TotalPayble
        {
            get { return _totalPayble; }
            set { _totalPayble = value; }
        }
        public double Pay
        {
            get { return _pay; }
            set { _pay = value; }
        }
        public double Due
        {
            get { return _due; }
            set { _due = value; }
        }
        public string PaymentDate
        {
            get { return _paymentDate; }
            set { _paymentDate = value; }
        }


      
      
       public List<Search> FlatWiseBill()
       {
           DataAccess aDataAccess = new DataAccess();
           return aDataAccess.GetFlatWiseBill(_flat);
       }
       public List<Search> MonthWiseBill()
       {
           DataAccess aDataAccess = new DataAccess();
           return aDataAccess.GetMonthWiseBill(_month);
       }


    }
}
