﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using ElectricityBillCalculationApplication.Database;

namespace ElectricityBillCalculationApplication.Model
{
   public class MonthInfo
    {

        private string _dateFrom = "";
        private string _dateTo = "";
        private string monthName = "";
        private int _billId = 0;

        public int BillId
        {
            get { return _billId; }
            set { _billId = value; }
        }
        public string DateFrom
        {
            get { return _dateFrom; }
            set { _dateFrom = value; }
        }
        public string DateTo
        {
            get { return _dateTo; }
            set { _dateTo = value; }
        }   
        public string MonthName
        {
            get { return monthName; }
            set { monthName = value; }
        }
        
        public int BillID(int TanentID)
        {
             DataAccess aDataAccess = new DataAccess();
             return aDataAccess.GetBillID(TanentID, monthName);
        }
        public void AddMonth()
        {
            DataAccess aDataAccess = new DataAccess();
            aDataAccess.InsertMonth(_dateFrom,
                                    _dateTo,
                                    monthName,
                                    _billId );
        }


        public DataSet Month()
        {
            DataAccess aDataAccess = new DataAccess();
            return aDataAccess.GetMonth();
        }

        public DataSet PreviewMonth(string month)
        {
            DataAccess aDataAccess = new DataAccess();
            return aDataAccess.GetMonth(month);
        }










    }
}
