﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ElectricityBillCalculationApplication.Database;

namespace ElectricityBillCalculationApplication.Model
{
   public class AdjustDue
    {
        private int _billId = 0;
        private string _month = "";
        private string _tanentName = "";
        private string _flat = "";
        private double _totalPayble = 0;
        private double _previousDue = 0;
        private double _adjustedDue = 0;
        private double _pay = 0;

        public double Pay
        {
            get { return _pay; }
            set { _pay = value; }
        }
        public double AdjustedDue
        {
            get { return _adjustedDue; }
            set { _adjustedDue = value; }
        }
        public double PreviousDue
        {
            get { return _previousDue; }
            set { _previousDue = value; }
        }
        public double TotalPayble
        {
            get { return _totalPayble; }
            set { _totalPayble = value; }
        }            
        public string Flat
        {
            get { return _flat; }
            set { _flat = value; }
        }
        public string TanentName
        {
            get { return _tanentName; }
            set { _tanentName = value; }
        }
        public string Month
        {
            get { return _month; }
            set { _month = value; }
        }
        public int BillId
        {
            get { return _billId; }
            set { _billId = value; }
        }

        public double DueAdjust()
        {
            return (_previousDue - _adjustedDue);
        }
        public double UpdatePay()
        {
            return (_pay + _adjustedDue);
        }
        public void UpdateDue()
        {
            DataAccess aDataAccess = new DataAccess();
            aDataAccess.DueUpdate(_billId,
                                    DueAdjust(),
                                    UpdatePay());
        }

        public List<AdjustDue> Due(int SelectBill)
        {
            DataAccess aDataAccess = new DataAccess();
            return aDataAccess.GetDue(SelectBill);
        }

        public int BillID(string flat, string month)
        {
            DataAccess aDataAccess = new DataAccess();
            return aDataAccess.GetBillID(flat, month);
        }

    }
}
