﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ElectricityBillCalculationApplication.Database;

namespace ElectricityBillCalculationApplication.Model
{
   public class PayDue
    {
        private int _billId = 0;
        private double _pay = 0;
        private double _due = 0;

        public double Due
        {
            get { return _due; }
            set { _due = value; }
        }

        public double Pay
        {
            get { return _pay; }
            set { _pay = value; }
        }

        public int BillId
        {
            get { return _billId; }
            set { _billId = value; }
        }


        public List<PayDue> PreviewPayDue(string flat, string month)
        {
            DataAccess aDataAccess = new DataAccess();
            return aDataAccess.GetPayDue(flat, month);
        }
    }
}
