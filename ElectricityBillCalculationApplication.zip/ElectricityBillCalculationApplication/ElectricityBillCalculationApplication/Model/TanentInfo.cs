﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using ElectricityBillCalculationApplication.Database;

namespace ElectricityBillCalculationApplication.Model
{
  public class TanentInfo
    {

        private string _TanentName = "";
        private string _Flat = "";
        private string _MeterNo = "";
        private int _tanentId = 0;

        public int TanentId
        {
            get { return _tanentId; }
            set { _tanentId = value; }
        }
        public string Flat
        {
            get { return _Flat; }
            set { _Flat = value; }
        }
        public string MeterNo
        {
            get { return _MeterNo; }
            set { _MeterNo = value; }
        }

        
        public string TanentName
        {
            get { return _TanentName; }
            set { _TanentName = value; }
        }
       


        DataAccess aDataAccess = new DataAccess();

        public void AddTanentInfo()
        {
            aDataAccess.InsertTanentInfo(_TanentName, _Flat, _MeterNo);

        }

        public DataSet Tanent()
        {
           return aDataAccess.GetTanentInfo();
        }

       public void UpdateTanentInfo(string Name,
                                    string Flat,
                                    string MeterNo)
        {

            DataAccess aDataAccess = new DataAccess();
            aDataAccess.UpdateTanent(Name, Flat, MeterNo);
        }

      public DataSet Tanent(int SelectTanent)
       {
           return aDataAccess.GetTanentInfo(SelectTanent);
       }




      public List<TanentInfo> Tanent(string flat)
      {
          return aDataAccess.GetTanentInfo(flat);
      }




    }
}
